module com.github.kwhat.jnativehook {
   requires java.desktop;
   requires java.logging;

   exports com.github.kwhat.jnativehook;
   exports com.github.kwhat.jnativehook.dispatcher;
   exports com.github.kwhat.jnativehook.keyboard;
   exports com.github.kwhat.jnativehook.mouse;
}
