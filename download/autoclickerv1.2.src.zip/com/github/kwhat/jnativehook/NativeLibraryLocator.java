package com.github.kwhat.jnativehook;

import java.util.Iterator;

public interface NativeLibraryLocator {
   Iterator getLibraries();
}
