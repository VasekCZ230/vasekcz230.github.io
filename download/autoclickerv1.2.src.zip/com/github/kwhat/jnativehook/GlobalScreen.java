package com.github.kwhat.jnativehook;

import com.github.kwhat.jnativehook.dispatcher.DefaultDispatchService;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import com.github.kwhat.jnativehook.mouse.NativeMouseEvent;
import com.github.kwhat.jnativehook.mouse.NativeMouseListener;
import com.github.kwhat.jnativehook.mouse.NativeMouseMotionListener;
import com.github.kwhat.jnativehook.mouse.NativeMouseWheelEvent;
import com.github.kwhat.jnativehook.mouse.NativeMouseWheelListener;
import java.io.File;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.logging.Logger;
import javax.swing.event.EventListenerList;

public class GlobalScreen {
   protected static Logger log = Logger.getLogger(GlobalScreen.class.getPackage().getName());
   protected static NativeHookThread hookThread;
   protected static ExecutorService eventExecutor;
   protected static EventListenerList eventListeners = new EventListenerList();

   protected GlobalScreen() {
   }

   public static void addNativeKeyListener(NativeKeyListener listener) {
      if (listener != null) {
         eventListeners.add(NativeKeyListener.class, listener);
      }

   }

   public static void removeNativeKeyListener(NativeKeyListener listener) {
      if (listener != null) {
         eventListeners.remove(NativeKeyListener.class, listener);
      }

   }

   public static void addNativeMouseListener(NativeMouseListener listener) {
      if (listener != null) {
         eventListeners.add(NativeMouseListener.class, listener);
      }

   }

   public static void removeNativeMouseListener(NativeMouseListener listener) {
      if (listener != null) {
         eventListeners.remove(NativeMouseListener.class, listener);
      }

   }

   public static void addNativeMouseMotionListener(NativeMouseMotionListener listener) {
      if (listener != null) {
         eventListeners.add(NativeMouseMotionListener.class, listener);
      }

   }

   public static void removeNativeMouseMotionListener(NativeMouseMotionListener listener) {
      if (listener != null) {
         eventListeners.remove(NativeMouseMotionListener.class, listener);
      }

   }

   public static void addNativeMouseWheelListener(NativeMouseWheelListener listener) {
      if (listener != null) {
         eventListeners.add(NativeMouseWheelListener.class, listener);
      }

   }

   public static void removeNativeMouseWheelListener(NativeMouseWheelListener listener) {
      if (listener != null) {
         eventListeners.remove(NativeMouseWheelListener.class, listener);
      }

   }

   public static native NativeMonitorInfo[] getNativeMonitors();

   public static native Integer getAutoRepeatRate();

   public static native Integer getAutoRepeatDelay();

   public static native Integer getPointerAccelerationMultiplier();

   public static native Integer getPointerAccelerationThreshold();

   public static native Integer getPointerSensitivity();

   public static native Integer getMultiClickIterval();

   public static void registerNativeHook() throws NativeHookException {
      if (eventExecutor != null) {
         if (!eventExecutor.isShutdown()) {
            eventExecutor.shutdown();
         }

         while(!eventExecutor.isTerminated()) {
            Thread.yield();
         }
      } else {
         eventExecutor = new DefaultDispatchService();
      }

      if (hookThread == null || !hookThread.isAlive()) {
         hookThread = new NativeHookThread();
         synchronized(hookThread) {
            hookThread.start();

            try {
               hookThread.wait();
            } catch (InterruptedException var3) {
               throw new NativeHookException(var3);
            }

            NativeHookException exception = hookThread.getException();
            if (exception != null) {
               throw exception;
            }
         }
      }

   }

   public static void unregisterNativeHook() throws NativeHookException {
      if (isNativeHookRegistered()) {
         synchronized(hookThread) {
            try {
               hookThread.disable();
               hookThread.join();
            } catch (Exception var3) {
               throw new NativeHookException(var3.getCause());
            }
         }

         eventExecutor.shutdown();
      }

   }

   public static boolean isNativeHookRegistered() {
      return hookThread != null && hookThread.isAlive();
   }

   public static native void postNativeEvent(NativeInputEvent var0);

   public static void setEventDispatcher(ExecutorService dispatcher) {
      if (eventExecutor != null) {
         eventExecutor.shutdown();
      }

      eventExecutor = dispatcher;
   }

   static {
      String libName = System.getProperty("jnativehook.lib.name", "JNativeHook");

      try {
         System.loadLibrary(libName);
      } catch (UnsatisfiedLinkError var8) {
         String libLoader = System.getProperty("jnativehook.lib.locator", DefaultLibraryLocator.class.getCanonicalName());

         try {
            NativeLibraryLocator locator = (NativeLibraryLocator)Class.forName(libLoader).asSubclass(NativeLibraryLocator.class).getDeclaredConstructor().newInstance();
            Iterator libs = locator.getLibraries();

            while(libs.hasNext()) {
               File lib = (File)libs.next();
               if (lib.exists() && lib.isFile() && lib.canRead()) {
                  System.load(lib.getPath());
               }
            }
         } catch (Exception var7) {
            log.severe(var7.getMessage());
            throw new UnsatisfiedLinkError(var7.getMessage());
         }
      }

      Integer autoRepeatRate = getAutoRepeatRate();
      if (autoRepeatRate != null) {
         System.setProperty("jnativehook.key.repeat.rate", autoRepeatRate.toString());
      }

      Integer autoRepeatDelay = getAutoRepeatDelay();
      if (autoRepeatDelay != null) {
         System.setProperty("jnativehook.key.repeat.delay", autoRepeatDelay.toString());
      }

      Integer multiClickIterval = getMultiClickIterval();
      if (multiClickIterval != null) {
         System.setProperty("jnativehook.button.multiclick.iterval", multiClickIterval.toString());
      }

      Integer pointerSensitivity = getPointerSensitivity();
      if (pointerSensitivity != null) {
         System.setProperty("jnativehook.pointer.sensitivity", pointerSensitivity.toString());
      }

      Integer pointerAccelerationMultiplier = getPointerAccelerationMultiplier();
      if (pointerAccelerationMultiplier != null) {
         System.setProperty("jnativehook.pointer.acceleration.multiplier", pointerAccelerationMultiplier.toString());
      }

      Integer pointerAccelerationThreshold = getPointerAccelerationThreshold();
      if (pointerAccelerationThreshold != null) {
         System.setProperty("jnativehook.pointer.acceleration.threshold", pointerAccelerationThreshold.toString());
      }

   }

   protected static class NativeHookThread extends Thread {
      protected NativeHookException exception;

      public NativeHookThread() {
         this.setName("JNativeHook Hook Thread");
         this.setDaemon(false);
         this.setPriority(10);
      }

      public void run() {
         this.exception = null;

         try {
            this.enable();
         } catch (NativeHookException var4) {
            this.exception = var4;
         }

         synchronized(this) {
            this.notifyAll();
         }
      }

      public NativeHookException getException() {
         return this.exception;
      }

      protected native void enable() throws NativeHookException;

      public native void disable() throws NativeHookException;

      protected static void dispatchEvent(NativeInputEvent event) {
         if (GlobalScreen.eventExecutor != null) {
            GlobalScreen.eventExecutor.execute(new EventDispatchTask(event));
         }

      }
   }

   private static class EventDispatchTask implements Runnable {
      private final NativeInputEvent event;

      public EventDispatchTask(NativeInputEvent event) {
         this.event = event;
      }

      public void run() {
         if (this.event instanceof NativeKeyEvent) {
            this.processKeyEvent((NativeKeyEvent)this.event);
         } else if (this.event instanceof NativeMouseWheelEvent) {
            this.processMouseWheelEvent((NativeMouseWheelEvent)this.event);
         } else if (this.event instanceof NativeMouseEvent) {
            switch (this.event.getID()) {
               case 2500:
               case 2501:
               case 2502:
                  this.processButtonEvent((NativeMouseEvent)this.event);
                  break;
               case 2503:
               case 2504:
                  this.processMouseEvent((NativeMouseEvent)this.event);
            }
         }

      }

      private void processKeyEvent(NativeKeyEvent nativeEvent) {
         NativeKeyListener[] listeners = (NativeKeyListener[])GlobalScreen.eventListeners.getListeners(NativeKeyListener.class);
         NativeKeyListener[] var3 = listeners;
         int var4 = listeners.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            NativeKeyListener listener = var3[var5];
            switch (nativeEvent.getID()) {
               case 2400:
                  listener.nativeKeyTyped(nativeEvent);
                  break;
               case 2401:
                  listener.nativeKeyPressed(nativeEvent);
                  break;
               case 2402:
                  listener.nativeKeyReleased(nativeEvent);
            }
         }

      }

      private void processButtonEvent(NativeMouseEvent nativeEvent) {
         NativeMouseListener[] listeners = (NativeMouseListener[])GlobalScreen.eventListeners.getListeners(NativeMouseListener.class);
         NativeMouseListener[] var3 = listeners;
         int var4 = listeners.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            NativeMouseListener listener = var3[var5];
            switch (nativeEvent.getID()) {
               case 2500:
                  listener.nativeMouseClicked(nativeEvent);
                  break;
               case 2501:
                  listener.nativeMousePressed(nativeEvent);
                  break;
               case 2502:
                  listener.nativeMouseReleased(nativeEvent);
            }
         }

      }

      private void processMouseEvent(NativeMouseEvent nativeEvent) {
         NativeMouseMotionListener[] listeners = (NativeMouseMotionListener[])GlobalScreen.eventListeners.getListeners(NativeMouseMotionListener.class);
         NativeMouseMotionListener[] var3 = listeners;
         int var4 = listeners.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            NativeMouseMotionListener listener = var3[var5];
            switch (nativeEvent.getID()) {
               case 2503:
                  listener.nativeMouseMoved(nativeEvent);
                  break;
               case 2504:
                  listener.nativeMouseDragged(nativeEvent);
            }
         }

      }

      private void processMouseWheelEvent(NativeMouseWheelEvent nativeEvent) {
         NativeMouseWheelListener[] listeners = (NativeMouseWheelListener[])GlobalScreen.eventListeners.getListeners(NativeMouseWheelListener.class);
         NativeMouseWheelListener[] var3 = listeners;
         int var4 = listeners.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            NativeMouseWheelListener listener = var3[var5];
            listener.nativeMouseWheelMoved(nativeEvent);
         }

      }
   }
}
