package com.github.kwhat.jnativehook;

import java.util.Locale;

public class NativeSystem {
   public static Family getFamily() {
      String osName = System.getProperty("os.name").toLowerCase(Locale.ROOT);
      Family family = NativeSystem.Family.UNSUPPORTED;
      if (osName.equals("freebsd")) {
         family = NativeSystem.Family.FREEBSD;
      } else if (osName.equals("openbsd")) {
         family = NativeSystem.Family.OPENBSD;
      } else if (osName.equals("mac os x")) {
         family = NativeSystem.Family.DARWIN;
      } else if (!osName.equals("solaris") && !osName.equals("sunos")) {
         if (osName.equals("linux")) {
            family = NativeSystem.Family.LINUX;
         } else if (osName.startsWith("windows")) {
            family = NativeSystem.Family.WINDOWS;
         }
      } else {
         family = NativeSystem.Family.SOLARIS;
      }

      return family;
   }

   public static Arch getArchitecture() {
      String osArch = System.getProperty("os.arch").toLowerCase(Locale.ROOT);
      Arch arch = NativeSystem.Arch.UNSUPPORTED;
      if (osArch.startsWith("arm")) {
         arch = NativeSystem.Arch.ARM;
      } else if (osArch.equals("aarch64")) {
         arch = NativeSystem.Arch.ARM64;
      } else if (osArch.equals("sparc")) {
         arch = NativeSystem.Arch.SPARC;
      } else if (osArch.equals("sparc64")) {
         arch = NativeSystem.Arch.SPARC64;
      } else if (!osArch.equals("ppc") && !osArch.equals("powerpc")) {
         if (!osArch.equals("ppc64") && !osArch.equals("powerpc64")) {
            if (!osArch.equals("x86") && !osArch.equals("i386") && !osArch.equals("i486") && !osArch.equals("i586") && !osArch.equals("i686")) {
               if (osArch.equals("x86_64") || osArch.equals("amd64") || osArch.equals("k8")) {
                  arch = NativeSystem.Arch.x86_64;
               }
            } else {
               arch = NativeSystem.Arch.x86;
            }
         } else {
            arch = NativeSystem.Arch.PPC64;
         }
      } else {
         arch = NativeSystem.Arch.PPC;
      }

      return arch;
   }

   public static enum Family {
      FREEBSD,
      OPENBSD,
      DARWIN,
      SOLARIS,
      LINUX,
      WINDOWS,
      UNSUPPORTED;

      public String toString() {
         return super.toString().toLowerCase(Locale.ROOT);
      }

      // $FF: synthetic method
      private static Family[] $values() {
         return new Family[]{FREEBSD, OPENBSD, DARWIN, SOLARIS, LINUX, WINDOWS, UNSUPPORTED};
      }
   }

   public static enum Arch {
      ARM,
      ARM64,
      SPARC,
      SPARC64,
      PPC,
      PPC64,
      x86,
      x86_64,
      UNSUPPORTED;

      public String toString() {
         return super.toString().toLowerCase(Locale.ROOT);
      }

      // $FF: synthetic method
      private static Arch[] $values() {
         return new Arch[]{ARM, ARM64, SPARC, SPARC64, PPC, PPC64, x86, x86_64, UNSUPPORTED};
      }
   }
}
