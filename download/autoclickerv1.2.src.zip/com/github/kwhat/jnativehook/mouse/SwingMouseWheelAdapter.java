package com.github.kwhat.jnativehook.mouse;

import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class SwingMouseWheelAdapter extends SwingMouseAdapter implements NativeMouseWheelListener, MouseWheelListener {
   public void nativeMouseWheelMoved(NativeMouseWheelEvent nativeEvent) {
      this.mouseWheelMoved(this.getJavaMouseWheelEvent(nativeEvent));
   }

   public void mouseWheelMoved(MouseWheelEvent mouseWheelEvent) {
   }

   protected MouseWheelEvent getJavaMouseWheelEvent(NativeMouseWheelEvent nativeEvent) {
      int scrollType = 0;
      if (nativeEvent.getScrollType() == 2) {
         scrollType = 1;
      }

      return new MouseWheelEvent(this, nativeEvent.getID() - 2000, System.currentTimeMillis(), this.getJavaModifiers(nativeEvent.getModifiers()), nativeEvent.getX(), nativeEvent.getY(), nativeEvent.getClickCount(), false, scrollType, nativeEvent.getScrollAmount(), nativeEvent.getWheelRotation());
   }
}
