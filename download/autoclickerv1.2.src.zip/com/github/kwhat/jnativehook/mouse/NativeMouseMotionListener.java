package com.github.kwhat.jnativehook.mouse;

import java.util.EventListener;

public interface NativeMouseMotionListener extends EventListener {
   default void nativeMouseMoved(NativeMouseEvent nativeEvent) {
   }

   default void nativeMouseDragged(NativeMouseEvent nativeEvent) {
   }
}
