package com.github.kwhat.jnativehook.mouse;

import java.util.EventListener;

public interface NativeMouseWheelListener extends EventListener {
   default void nativeMouseWheelMoved(NativeMouseWheelEvent nativeEvent) {
   }
}
