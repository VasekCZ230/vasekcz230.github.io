package com.github.kwhat.jnativehook.mouse;

/** @deprecated */
@Deprecated
public class NativeMouseMotionAdapter implements NativeMouseMotionListener {
}
