package com.github.kwhat.jnativehook.mouse;

import com.github.kwhat.jnativehook.AbstractSwingInputAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class SwingMouseAdapter extends AbstractSwingInputAdapter implements NativeMouseListener, MouseListener {
   public void nativeMouseClicked(NativeMouseEvent nativeEvent) {
      this.mouseClicked(this.getJavaKeyEvent(nativeEvent));
   }

   public void nativeMousePressed(NativeMouseEvent nativeEvent) {
      this.mousePressed(this.getJavaKeyEvent(nativeEvent));
   }

   public void nativeMouseReleased(NativeMouseEvent nativeEvent) {
      this.mouseReleased(this.getJavaKeyEvent(nativeEvent));
   }

   public void mouseClicked(MouseEvent mouseEvent) {
   }

   public void mousePressed(MouseEvent mouseEvent) {
   }

   public void mouseReleased(MouseEvent mouseEvent) {
   }

   public void mouseEntered(MouseEvent mouseEvent) {
   }

   public void mouseExited(MouseEvent mouseEvent) {
   }

   protected MouseEvent getJavaKeyEvent(NativeMouseEvent nativeEvent) {
      return new MouseEvent(this, nativeEvent.getID() - 2000, System.currentTimeMillis(), this.getJavaModifiers(nativeEvent.getModifiers()), nativeEvent.getX(), nativeEvent.getY(), nativeEvent.getClickCount(), false, nativeEvent.getButton());
   }
}
