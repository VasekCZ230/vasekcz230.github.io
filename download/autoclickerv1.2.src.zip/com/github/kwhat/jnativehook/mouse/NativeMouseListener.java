package com.github.kwhat.jnativehook.mouse;

import java.util.EventListener;

public interface NativeMouseListener extends EventListener {
   default void nativeMouseClicked(NativeMouseEvent nativeEvent) {
   }

   default void nativeMousePressed(NativeMouseEvent nativeEvent) {
   }

   default void nativeMouseReleased(NativeMouseEvent nativeEvent) {
   }
}
