package com.github.kwhat.jnativehook.mouse;

/** @deprecated */
@Deprecated
public class NativeMouseWheelAdapter implements NativeMouseWheelListener {
}
