package com.github.kwhat.jnativehook.mouse;

public interface NativeMouseInputListener extends NativeMouseListener, NativeMouseMotionListener {
}
