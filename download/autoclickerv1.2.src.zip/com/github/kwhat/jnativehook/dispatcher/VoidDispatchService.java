package com.github.kwhat.jnativehook.dispatcher;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.TimeUnit;

public class VoidDispatchService extends AbstractExecutorService {
   private boolean running = false;

   public VoidDispatchService() {
      this.running = true;
   }

   public void shutdown() {
      this.running = false;
   }

   public List shutdownNow() {
      this.running = false;
      return new ArrayList(0);
   }

   public boolean isShutdown() {
      return !this.running;
   }

   public boolean isTerminated() {
      return !this.running;
   }

   public boolean awaitTermination(long timeout, TimeUnit unit) {
      return true;
   }

   public void execute(Runnable r) {
      r.run();
   }
}
