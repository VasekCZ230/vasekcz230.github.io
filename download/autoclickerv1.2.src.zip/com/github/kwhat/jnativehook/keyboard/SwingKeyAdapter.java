package com.github.kwhat.jnativehook.keyboard;

import com.github.kwhat.jnativehook.AbstractSwingInputAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class SwingKeyAdapter extends AbstractSwingInputAdapter implements NativeKeyListener, KeyListener {
   public void nativeKeyTyped(NativeKeyEvent nativeEvent) {
      this.keyTyped(this.getJavaKeyEvent(nativeEvent));
   }

   public void nativeKeyPressed(NativeKeyEvent nativeEvent) {
      this.keyPressed(this.getJavaKeyEvent(nativeEvent));
   }

   public void nativeKeyReleased(NativeKeyEvent nativeEvent) {
      this.keyReleased(this.getJavaKeyEvent(nativeEvent));
   }

   public void keyTyped(KeyEvent keyEvent) {
   }

   public void keyPressed(KeyEvent keyEvent) {
   }

   public void keyReleased(KeyEvent keyEvent) {
   }

   protected KeyEvent getJavaKeyEvent(NativeKeyEvent nativeEvent) {
      int keyLocation = 0;
      switch (nativeEvent.getKeyLocation()) {
         case 1:
            keyLocation = 1;
            break;
         case 2:
            keyLocation = 1;
            break;
         case 3:
            keyLocation = 3;
            break;
         case 4:
            keyLocation = 4;
      }

      int keyCode = 0;
      switch (nativeEvent.getKeyCode()) {
         case 1:
            keyCode = 27;
            break;
         case 2:
            keyCode = '1';
            break;
         case 3:
            keyCode = '2';
            break;
         case 4:
            keyCode = '3';
            break;
         case 5:
            keyCode = '4';
            break;
         case 6:
            keyCode = '5';
            break;
         case 7:
            keyCode = '6';
            break;
         case 8:
            keyCode = '7';
            break;
         case 9:
            keyCode = '8';
            break;
         case 10:
            keyCode = '9';
            break;
         case 11:
            keyCode = '0';
            break;
         case 12:
            keyCode = '-';
            break;
         case 13:
            keyCode = '=';
            break;
         case 14:
            keyCode = '\b';
            break;
         case 15:
            keyCode = '\t';
            break;
         case 16:
            keyCode = 'Q';
            break;
         case 17:
            keyCode = 'W';
            break;
         case 18:
            keyCode = 'E';
            break;
         case 19:
            keyCode = 'R';
            break;
         case 20:
            keyCode = 'T';
            break;
         case 21:
            keyCode = 'Y';
            break;
         case 22:
            keyCode = 'U';
            break;
         case 23:
            keyCode = 'I';
            break;
         case 24:
            keyCode = 'O';
            break;
         case 25:
            keyCode = 'P';
            break;
         case 26:
            keyCode = '[';
            break;
         case 27:
            keyCode = ']';
            break;
         case 28:
            keyCode = '\n';
            break;
         case 29:
            keyCode = 17;
            break;
         case 30:
            keyCode = 'A';
            break;
         case 31:
            keyCode = 'S';
            break;
         case 32:
            keyCode = 'D';
            break;
         case 33:
            keyCode = 'F';
            break;
         case 34:
            keyCode = 'G';
            break;
         case 35:
            keyCode = 'H';
            break;
         case 36:
            keyCode = 'J';
            break;
         case 37:
            keyCode = 'K';
            break;
         case 38:
            keyCode = 'L';
            break;
         case 39:
            keyCode = ';';
            break;
         case 40:
            keyCode = 222;
            break;
         case 41:
            keyCode = 192;
            break;
         case 42:
            keyCode = 16;
            break;
         case 43:
            keyCode = '\\';
            break;
         case 44:
            keyCode = 'Z';
            break;
         case 45:
            keyCode = 'X';
            break;
         case 46:
            keyCode = 'C';
            break;
         case 47:
            keyCode = 'V';
            break;
         case 48:
            keyCode = 'B';
            break;
         case 49:
            keyCode = 'N';
            break;
         case 50:
            keyCode = 'M';
            break;
         case 51:
            keyCode = ',';
            break;
         case 52:
            keyCode = '.';
            break;
         case 53:
            keyCode = '/';
            break;
         case 56:
            keyCode = 18;
            break;
         case 57:
            keyCode = ' ';
            break;
         case 58:
            keyCode = 20;
            break;
         case 59:
            keyCode = 'p';
            break;
         case 60:
            keyCode = 'q';
            break;
         case 61:
            keyCode = 'r';
            break;
         case 62:
            keyCode = 's';
            break;
         case 63:
            keyCode = 't';
            break;
         case 64:
            keyCode = 'u';
            break;
         case 65:
            keyCode = 'v';
            break;
         case 66:
            keyCode = 'w';
            break;
         case 67:
            keyCode = 'x';
            break;
         case 68:
            keyCode = 'y';
            break;
         case 69:
            keyCode = 144;
            break;
         case 70:
            keyCode = 145;
            break;
         case 83:
            keyCode = 'l';
            break;
         case 87:
            keyCode = 'z';
            break;
         case 88:
            keyCode = '{';
            break;
         case 91:
            keyCode = '\uf000';
            break;
         case 92:
            keyCode = '\uf001';
            break;
         case 93:
            keyCode = '\uf002';
            break;
         case 99:
            keyCode = '\uf003';
            break;
         case 100:
            keyCode = '\uf004';
            break;
         case 101:
            keyCode = '\uf005';
            break;
         case 102:
            keyCode = '\uf006';
            break;
         case 103:
            keyCode = '\uf007';
            break;
         case 104:
            keyCode = '\uf008';
            break;
         case 105:
            keyCode = '\uf009';
            break;
         case 106:
            keyCode = '\uf00a';
            break;
         case 107:
            keyCode = '\uf00b';
            break;
         case 112:
            keyCode = 241;
            break;
         case 115:
            keyCode = 523;
            break;
         case 121:
            keyCode = 25;
            break;
         case 123:
            keyCode = 242;
            break;
         case 3639:
            keyCode = 154;
            break;
         case 3653:
            keyCode = 19;
            break;
         case 3655:
            keyCode = '$';
            break;
         case 3657:
            keyCode = '!';
            break;
         case 3663:
            keyCode = '#';
            break;
         case 3665:
            keyCode = '"';
            break;
         case 3666:
            keyCode = 155;
            break;
         case 3667:
            keyCode = 127;
            break;
         case 3675:
            keyCode = 157;
            break;
         case 3677:
            keyCode = 525;
            break;
         case 57416:
            keyCode = '&';
            break;
         case 57419:
            keyCode = '%';
            break;
         case 57420:
            keyCode = '\f';
            break;
         case 57421:
            keyCode = '\'';
            break;
         case 57424:
            keyCode = '(';
            break;
         case 65397:
            keyCode = 156;
            break;
         case 65398:
            keyCode = 'ￊ';
            break;
         case 65400:
            keyCode = '\uffc8';
            break;
         case 65401:
            keyCode = '\uffc9';
            break;
         case 65403:
            keyCode = '\uffd1';
            break;
         case 65404:
            keyCode = 'ￍ';
            break;
         case 65406:
            keyCode = '\uffd0';
      }

      return new KeyEvent(this, nativeEvent.getID() - 2000, System.currentTimeMillis(), this.getJavaModifiers(nativeEvent.getModifiers()), keyCode, nativeEvent.getKeyChar(), keyLocation);
   }
}
