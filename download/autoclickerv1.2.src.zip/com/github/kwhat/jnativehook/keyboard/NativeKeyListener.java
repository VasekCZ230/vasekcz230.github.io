package com.github.kwhat.jnativehook.keyboard;

import java.util.EventListener;

public interface NativeKeyListener extends EventListener {
   default void nativeKeyTyped(NativeKeyEvent nativeEvent) {
   }

   default void nativeKeyPressed(NativeKeyEvent nativeEvent) {
   }

   default void nativeKeyReleased(NativeKeyEvent nativeEvent) {
   }
}
