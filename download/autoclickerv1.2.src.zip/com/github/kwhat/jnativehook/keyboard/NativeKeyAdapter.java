package com.github.kwhat.jnativehook.keyboard;

/** @deprecated */
@Deprecated
public class NativeKeyAdapter implements NativeKeyListener {
}
