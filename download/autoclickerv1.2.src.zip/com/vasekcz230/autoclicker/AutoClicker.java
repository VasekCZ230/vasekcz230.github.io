package com.vasekcz230.autoclicker;

import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.NativeHookException;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import java.awt.AWTException;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Robot;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class AutoClicker extends JFrame implements NativeKeyListener {
   private Robot robot;
   private boolean isClicking = false;
   private Thread clickThread;
   private JTextField delayField;
   private JTextField durationField;
   private JComboBox hotkeyBox;
   private JComboBox buttonBox;
   private JLabel statusLabel;
   private int maxClickTimeMs = 0;
   private int selectedKeyCode = 64;

   public AutoClicker() {
      this.setTitle("Auto Clicker v1.2");
      this.setSize(325, 150);
      this.setDefaultCloseOperation(3);
      this.setLayout(new FlowLayout());

      try {
         this.robot = new Robot();
      } catch (AWTException var4) {
         JOptionPane.showMessageDialog(this, "Robot initialization failed", "Error", 0);
         System.exit(1);
      }

      this.add(new JLabel("Click Delay (ms):"));
      this.delayField = new JTextField("100", 10);
      this.add(this.delayField);
      this.add(new JLabel("Max Click Time (sec, 0 = infinite):"));
      this.durationField = new JTextField("30", 10);
      this.add(this.durationField);
      this.add(new JLabel("Mouse Button:"));
      this.buttonBox = new JComboBox(new String[]{"Left", "Right", "Middle"});
      this.add(this.buttonBox);
      this.add(new JLabel("Start/Stop Key:"));
      this.hotkeyBox = new JComboBox(new String[]{"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"});
      this.hotkeyBox.setSelectedItem("F6");
      this.add(this.hotkeyBox);
      this.statusLabel = new JLabel("Status: Stopped");
      this.add(this.statusLabel);
      Logger logger = Logger.getLogger(GlobalScreen.class.getPackage().getName());
      logger.setLevel(Level.WARNING);
      logger.setUseParentHandlers(false);

      try {
         GlobalScreen.registerNativeHook();
      } catch (NativeHookException var3) {
         JOptionPane.showMessageDialog(this, "Global key hook failed", "Error", 0);
         System.exit(1);
      }

      GlobalScreen.addNativeKeyListener(this);
      this.setLocationRelativeTo((Component)null);
      this.setVisible(true);
   }

   public void nativeKeyPressed(NativeKeyEvent e) {
      String selectedKey = (String)this.hotkeyBox.getSelectedItem();
      int keyCode = this.getNativeKeyCode(selectedKey);
      if (e.getKeyCode() == keyCode) {
         if (!this.isClicking) {
            this.startClicking();
         } else {
            this.stopClicking();
         }
      }

   }

   public void nativeKeyReleased(NativeKeyEvent e) {
   }

   public void nativeKeyTyped(NativeKeyEvent e) {
   }

   private int getNativeKeyCode(String key) {
      try {
         return NativeKeyEvent.class.getField("VC_" + key).getInt((Object)null);
      } catch (Exception var3) {
         return 64;
      }
   }

   private int getMouseButtonMask() {
      String selectedButton = (String)this.buttonBox.getSelectedItem();
      if ("Right".equals(selectedButton)) {
         return 4096;
      } else {
         return "Middle".equals(selectedButton) ? 2048 : 1024;
      }
   }

   private void startClicking() {
      if (!this.isClicking) {
         final int delay;
         try {
            delay = Integer.parseInt(this.delayField.getText());
         } catch (NumberFormatException var4) {
            JOptionPane.showMessageDialog(this, "Invalid delay value", "Error", 0);
            return;
         }

         final int buttonMask;
         try {
            buttonMask = Integer.parseInt(this.durationField.getText());
            this.maxClickTimeMs = buttonMask <= 0 ? 0 : buttonMask * 1000;
         } catch (NumberFormatException var3) {
            JOptionPane.showMessageDialog(this, "Invalid duration value", "Error", 0);
            return;
         }

         buttonMask = this.getMouseButtonMask();
         this.isClicking = true;
         this.updateStatusLabel();
         this.clickThread = new Thread(new Runnable() {
            public void run() {
               long startTime = System.currentTimeMillis();

               while(AutoClicker.this.isClicking) {
                  AutoClicker.this.robot.mousePress(buttonMask);
                  AutoClicker.this.robot.mouseRelease(buttonMask);

                  try {
                     Thread.sleep((long)delay);
                  } catch (InterruptedException var4) {
                     break;
                  }

                  if (AutoClicker.this.maxClickTimeMs > 0 && System.currentTimeMillis() - startTime >= (long)AutoClicker.this.maxClickTimeMs) {
                     AutoClicker.this.stopClicking();
                     break;
                  }
               }

            }
         });
         this.clickThread.start();
      }
   }

   private void stopClicking() {
      this.isClicking = false;
      this.updateStatusLabel();
      if (this.clickThread != null && this.clickThread.isAlive()) {
         this.clickThread.interrupt();
      }

   }

   private void updateStatusLabel() {
      if (this.isClicking) {
         this.statusLabel.setText("Status: Running");
      } else {
         this.statusLabel.setText("Status: Stopped");
      }

   }

   public static void main(String[] args) {
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            new AutoClicker();
         }
      });
   }
}
