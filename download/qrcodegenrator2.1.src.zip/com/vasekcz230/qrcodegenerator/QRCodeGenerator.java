package com.vasekcz230.qrcodegenerator;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageConfig;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class QRCodeGenerator {
   private JTextField textField;
   private JButton colorButton;
   private JButton saveButton;
   private Color qrColor;
   private BufferedImage qrImage;
   private JLabel qrPreviewLabel;

   public QRCodeGenerator() {
      this.qrColor = Color.BLACK;
   }

   public static void main(String[] args) {
      (new QRCodeGenerator()).createUI();
   }

   private void createUI() {
      JFrame frame = new JFrame("QR Code Generator v2.1");
      frame.setSize(600, 500);
      frame.setDefaultCloseOperation(3);
      frame.setLayout(new BorderLayout());
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      int x = (screenSize.width - frame.getWidth()) / 2;
      int y = (screenSize.height - frame.getHeight()) / 2;
      frame.setLocation(x, y);
      JPanel inputPanel = new JPanel(new GridLayout(0, 1));
      JPanel previewPanel = new JPanel(new BorderLayout());
      JPanel buttonPanel = new JPanel(new GridBagLayout());
      this.textField = new JTextField("Write Text or URL");
      this.textField.setForeground(Color.GRAY);
      inputPanel.add(this.textField);
      this.textField.addKeyListener(new KeyAdapter() {
         public void keyReleased(KeyEvent e) {
            if (!QRCodeGenerator.this.textField.getText().isEmpty() && !QRCodeGenerator.this.textField.getText().equals("Write Text or URL")) {
               QRCodeGenerator.this.textField.setForeground(Color.BLACK);
               QRCodeGenerator.this.regenerateQRCode();
            }

         }
      });
      this.textField.addFocusListener(new FocusAdapter() {
         public void focusGained(FocusEvent e) {
            if (QRCodeGenerator.this.textField.getText().equals("Write Text or URL")) {
               QRCodeGenerator.this.textField.setForeground(Color.BLACK);
               QRCodeGenerator.this.textField.setText("");
            }

         }

         public void focusLost(FocusEvent e) {
            if (QRCodeGenerator.this.textField.getText().isEmpty()) {
               QRCodeGenerator.this.textField.setForeground(Color.GRAY);
               QRCodeGenerator.this.textField.setText("Write Text or URL");
            }

         }
      });
      this.colorButton = new JButton("Select Color");
      inputPanel.add(this.colorButton);
      this.colorButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            QRCodeGenerator.this.qrColor = JColorChooser.showDialog((Component)null, "Select QR Code Color", QRCodeGenerator.this.qrColor);
            QRCodeGenerator.this.regenerateQRCode();
         }
      });
      this.qrPreviewLabel = new JLabel();
      this.qrPreviewLabel.setHorizontalAlignment(0);
      previewPanel.add(this.qrPreviewLabel, "Center");
      this.saveButton = new JButton("Save QR Code!");
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = 2;
      gbc.weightx = 1.0;
      gbc.gridx = 0;
      gbc.gridy = 0;
      buttonPanel.add(this.saveButton, gbc);
      this.saveButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            String text = QRCodeGenerator.this.textField.getText();
            if (QRCodeGenerator.this.qrImage != null && !text.isEmpty() && !text.equals("Write Text or URL")) {
               QRCodeGenerator.this.saveQRCode();
            } else {
               JOptionPane.showMessageDialog((Component)null, "Please enter text or URL to generate QR Code first!");
            }

         }
      });
      frame.add(inputPanel, "North");
      frame.add(previewPanel, "Center");
      frame.add(buttonPanel, "South");
      frame.setVisible(true);
      frame.requestFocus();
   }

   private void regenerateQRCode() {
      String text = this.textField.getText();
      if (!text.isEmpty() && !text.equals("Write Text or URL")) {
         int previewSize = Math.min(this.qrPreviewLabel.getWidth(), this.qrPreviewLabel.getHeight());
         int size = previewSize > 0 ? previewSize : 512;

         try {
            this.qrImage = this.generateQRCode(text, size, this.qrColor);
            this.displayQRCode(this.qrImage);
         } catch (WriterException | IOException var5) {
            var5.printStackTrace();
         }
      }

   }

   private BufferedImage generateQRCode(String text, int size, Color qrColor) throws WriterException, IOException {
      QRCodeWriter qrCodeWriter = new QRCodeWriter();
      BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, size, size);
      int qrColorValue = qrColor.getRGB();
      int backgroundColor = Color.WHITE.getRGB();
      MatrixToImageConfig config = new MatrixToImageConfig(qrColorValue, backgroundColor);
      BufferedImage qrImage = MatrixToImageWriter.toBufferedImage(bitMatrix, config);
      return qrImage;
   }

   private void displayQRCode(BufferedImage qrImage) {
      ImageIcon qrIcon = new ImageIcon(qrImage.getScaledInstance(250, 250, 4));
      this.qrPreviewLabel.setIcon(qrIcon);
   }

   private void saveQRCode() {
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setDialogTitle("Save QR Code");
      fileChooser.setSelectedFile(new File("qrcode.png"));
      int userSelection = fileChooser.showSaveDialog((Component)null);
      if (userSelection == 0) {
         File fileToSave = fileChooser.getSelectedFile();
         if (fileToSave.exists()) {
            int response = JOptionPane.showConfirmDialog((Component)null, "File already exists. Overwrite?", "Confirm Overwrite", 0, 3);
            if (response != 0) {
               return;
            }
         }

         try {
            ImageIO.write(this.qrImage, "PNG", fileToSave);
            JOptionPane.showMessageDialog((Component)null, "QR Code saved successfully!");
         } catch (IOException var5) {
            var5.printStackTrace();
            JOptionPane.showMessageDialog((Component)null, "Failed to save QR Code: " + var5.getMessage());
         }
      }

   }
}
