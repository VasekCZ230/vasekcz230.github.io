package com.google.zxing.common.reedsolomon;

public final class ReedSolomonException extends Exception {
   public ReedSolomonException(String message) {
      super(message);
   }
}
