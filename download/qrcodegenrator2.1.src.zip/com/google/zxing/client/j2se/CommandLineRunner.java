package com.google.zxing.client.j2se;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.DecodeHintType;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Pattern;

public final class CommandLineRunner {
   private static final Pattern COMMA = Pattern.compile(",");

   private CommandLineRunner() {
   }

   public static void main(String[] args) throws Exception {
      if (args.length == 0) {
         printUsage();
      } else {
         Config config = new Config();
         Queue inputs = new ConcurrentLinkedQueue();
         String[] arr$ = args;
         int successful = args.length;

         int total;
         for(total = 0; total < successful; ++total) {
            String arg = arr$[total];
            String[] argValue = arg.split("=");
            switch (argValue[0]) {
               case "--try_harder":
                  config.setTryHarder(true);
                  break;
               case "--pure_barcode":
                  config.setPureBarcode(true);
                  break;
               case "--products_only":
                  config.setProductsOnly(true);
                  break;
               case "--dump_results":
                  config.setDumpResults(true);
                  break;
               case "--dump_black_point":
                  config.setDumpBlackPoint(true);
                  break;
               case "--multi":
                  config.setMulti(true);
                  break;
               case "--brief":
                  config.setBrief(true);
                  break;
               case "--recursive":
                  config.setRecursive(true);
                  break;
               case "--crop":
                  int[] crop = new int[4];
                  String[] tokens = COMMA.split(argValue[1]);

                  for(int i = 0; i < crop.length; ++i) {
                     crop[i] = Integer.parseInt(tokens[i]);
                  }

                  config.setCrop(crop);
                  break;
               case "--possibleFormats":
                  config.setPossibleFormats(COMMA.split(argValue[1]));
                  break;
               default:
                  if (arg.startsWith("-")) {
                     System.err.println("Unknown command line option " + arg);
                     printUsage();
                     return;
                  }

                  addArgumentToInputs(Paths.get(arg), config, inputs);
            }
         }

         config.setHints(buildHints(config));
         int numThreads = Math.min(inputs.size(), Runtime.getRuntime().availableProcessors());
         successful = 0;
         if (numThreads > 1) {
            ExecutorService executor = Executors.newFixedThreadPool(numThreads);
            Collection futures = new ArrayList(numThreads);

            for(int x = 0; x < numThreads; ++x) {
               futures.add(executor.submit(new DecodeWorker(config, inputs)));
            }

            executor.shutdown();

            Future future;
            for(Iterator i$ = futures.iterator(); i$.hasNext(); successful += (Integer)future.get()) {
               future = (Future)i$.next();
            }
         } else {
            successful += (new DecodeWorker(config, inputs)).call();
         }

         total = inputs.size();
         if (total > 1) {
            System.out.println("\nDecoded " + successful + " files out of " + total + " successfully (" + successful * 100 / total + "%)\n");
         }

      }
   }

   private static void addArgumentToInputs(Path inputFile, Config config, Queue inputs) throws IOException {
      if (Files.isDirectory(inputFile, new LinkOption[0])) {
         DirectoryStream paths = Files.newDirectoryStream(inputFile);
         Throwable var4 = null;

         try {
            Iterator i$ = paths.iterator();

            while(i$.hasNext()) {
               Path singleFile = (Path)i$.next();
               String filename = singleFile.getFileName().toString().toLowerCase(Locale.ENGLISH);
               if (!filename.startsWith(".")) {
                  if (Files.isDirectory(singleFile, new LinkOption[0])) {
                     if (config.isRecursive()) {
                        addArgumentToInputs(singleFile, config, inputs);
                     }
                  } else if (!filename.endsWith(".txt") && !filename.contains(".mono.png")) {
                     inputs.add(singleFile);
                  }
               }
            }
         } catch (Throwable var15) {
            var4 = var15;
            throw var15;
         } finally {
            if (paths != null) {
               if (var4 != null) {
                  try {
                     paths.close();
                  } catch (Throwable var14) {
                     var4.addSuppressed(var14);
                  }
               } else {
                  paths.close();
               }
            }

         }
      } else {
         inputs.add(inputFile);
      }

   }

   private static Map buildHints(Config config) {
      Collection possibleFormats = new ArrayList();
      String[] possibleFormatsNames = config.getPossibleFormats();
      if (possibleFormatsNames != null && possibleFormatsNames.length > 0) {
         String[] arr$ = possibleFormatsNames;
         int len$ = possibleFormatsNames.length;

         for(int i$ = 0; i$ < len$; ++i$) {
            String format = arr$[i$];
            possibleFormats.add(BarcodeFormat.valueOf(format));
         }
      } else {
         possibleFormats.add(BarcodeFormat.UPC_A);
         possibleFormats.add(BarcodeFormat.UPC_E);
         possibleFormats.add(BarcodeFormat.EAN_13);
         possibleFormats.add(BarcodeFormat.EAN_8);
         possibleFormats.add(BarcodeFormat.RSS_14);
         possibleFormats.add(BarcodeFormat.RSS_EXPANDED);
         if (!config.isProductsOnly()) {
            possibleFormats.add(BarcodeFormat.CODE_39);
            possibleFormats.add(BarcodeFormat.CODE_93);
            possibleFormats.add(BarcodeFormat.CODE_128);
            possibleFormats.add(BarcodeFormat.ITF);
            possibleFormats.add(BarcodeFormat.QR_CODE);
            possibleFormats.add(BarcodeFormat.DATA_MATRIX);
            possibleFormats.add(BarcodeFormat.AZTEC);
            possibleFormats.add(BarcodeFormat.PDF_417);
            possibleFormats.add(BarcodeFormat.CODABAR);
            possibleFormats.add(BarcodeFormat.MAXICODE);
         }
      }

      Map hints = new EnumMap(DecodeHintType.class);
      hints.put(DecodeHintType.POSSIBLE_FORMATS, possibleFormats);
      if (config.isTryHarder()) {
         hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
      }

      if (config.isPureBarcode()) {
         hints.put(DecodeHintType.PURE_BARCODE, Boolean.TRUE);
      }

      return hints;
   }

   private static void printUsage() {
      System.err.println("Decode barcode images using the ZXing library");
      System.err.println();
      System.err.println("usage: CommandLineRunner { file | dir | url } [ options ]");
      System.err.println("  --try_harder: Use the TRY_HARDER hint, default is normal (mobile) mode");
      System.err.println("  --pure_barcode: Input image is a pure monochrome barcode image, not a photo");
      System.err.println("  --products_only: Only decode the UPC and EAN families of barcodes");
      System.err.println("  --dump_results: Write the decoded contents to input.txt");
      System.err.println("  --dump_black_point: Compare black point algorithms as input.mono.png");
      System.err.println("  --multi: Scans image for multiple barcodes");
      System.err.println("  --brief: Only output one line per file, omitting the contents");
      System.err.println("  --recursive: Descend into subdirectories");
      System.err.println("  --crop=left,top,width,height: Only examine cropped region of input image(s)");
      StringBuilder builder = new StringBuilder();
      builder.append("  --possibleFormats=barcodeFormat[,barcodeFormat2...] where barcodeFormat is any of: ");
      BarcodeFormat[] arr$ = BarcodeFormat.values();
      int len$ = arr$.length;

      for(int i$ = 0; i$ < len$; ++i$) {
         BarcodeFormat format = arr$[i$];
         builder.append(format).append(',');
      }

      builder.setLength(builder.length() - 1);
      System.err.println(builder);
   }
}
