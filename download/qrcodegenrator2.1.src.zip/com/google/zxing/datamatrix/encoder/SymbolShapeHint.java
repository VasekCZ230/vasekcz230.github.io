package com.google.zxing.datamatrix.encoder;

public enum SymbolShapeHint {
   FORCE_NONE,
   FORCE_SQUARE,
   FORCE_RECTANGLE;
}
