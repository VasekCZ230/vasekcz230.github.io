package cz.vasekcz230.programlauncher;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import sun.awt.shell.ShellFolder;

public class ProgramLauncher extends JFrame {
   private int windowWidth = 200;
   private int windowHeight = 500;
   private final List entries = new ArrayList();
   private JPanel buttonPanel;
   private JPanel searchPanel;
   private JTextField searchField;
   private JButton closeSearchButton;

   public static void main(String[] args) {
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            (new ProgramLauncher()).setVisible(true);
         }
      });
   }

   public ProgramLauncher() {
      this.setTitle("Program Launcher v2.1.2");
      this.setDefaultCloseOperation(3);
      this.loadConfig();
      this.setSize(this.windowWidth, this.windowHeight);
      this.setLocationRelativeTo((Component)null);
      this.setLayout(new BorderLayout());
      this.searchPanel = new JPanel(new BorderLayout());
      this.searchPanel.setVisible(false);
      this.searchField = new JTextField();
      this.searchPanel.add(this.searchField, "Center");
      this.closeSearchButton = new JButton("X");
      this.closeSearchButton.setPreferredSize(new Dimension(42, 25));
      this.searchPanel.add(this.closeSearchButton, "East");
      this.add(this.searchPanel, "North");
      this.buttonPanel = new JPanel();
      this.buttonPanel.setLayout(new BoxLayout(this.buttonPanel, 1));
      JScrollPane scrollPane = new JScrollPane(this.buttonPanel);
      this.add(scrollPane, "Center");
      this.searchField.getDocument().addDocumentListener(new DocumentListener() {
         public void insertUpdate(DocumentEvent e) {
            ProgramLauncher.this.filterButtons();
         }

         public void removeUpdate(DocumentEvent e) {
            ProgramLauncher.this.filterButtons();
         }

         public void changedUpdate(DocumentEvent e) {
            ProgramLauncher.this.filterButtons();
         }
      });
      this.closeSearchButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            ProgramLauncher.this.searchPanel.setVisible(false);
            ProgramLauncher.this.searchField.setText("");
            ProgramLauncher.this.buildButtons();
         }
      });
      this.getRootPane().getInputMap(2).put(KeyStroke.getKeyStroke("control F"), "showSearch");
      this.getRootPane().getInputMap(2).put(KeyStroke.getKeyStroke('/'), "showSearch");
      this.getRootPane().getActionMap().put("showSearch", new AbstractAction() {
         public void actionPerformed(ActionEvent e) {
            ProgramLauncher.this.showSearchPanel();
         }
      });
      this.buildButtons();
   }

   private void showSearchPanel() {
      this.searchPanel.setVisible(true);
      this.searchField.requestFocusInWindow();
      this.searchField.selectAll();
   }

   private void filterButtons() {
      String query = this.searchField.getText().trim().toLowerCase();
      this.buttonPanel.removeAll();
      if (query.isEmpty()) {
         this.buildButtons();
      } else {
         boolean matchedCategory = false;

         LabelEntry le;
         LauncherEntry entry;
         for(int i = 0; i < this.entries.size(); ++i) {
            entry = (LauncherEntry)this.entries.get(i);
            if (entry instanceof LabelEntry) {
               le = (LabelEntry)entry;
               String labelLower = le.label.toLowerCase();
               if (labelLower.contains(query)) {
                  matchedCategory = true;
                  this.addLabel(le.label);

                  for(int j = i + 1; j < this.entries.size(); ++j) {
                     LauncherEntry nextEntry = (LauncherEntry)this.entries.get(j);
                     if (nextEntry instanceof LabelEntry) {
                        break;
                     }

                     if (nextEntry instanceof ProgramEntry) {
                        this.addProgramButton((ProgramEntry)nextEntry);
                     }
                  }
               }
            }
         }

         if (!matchedCategory) {
            Iterator var10 = this.entries.iterator();

            while(var10.hasNext()) {
               entry = (LauncherEntry)var10.next();
               if (entry instanceof LabelEntry) {
                  le = (LabelEntry)entry;
                  if (le.label.toLowerCase().contains(query)) {
                     this.addLabel(le.label);
                  }
               } else if (entry instanceof ProgramEntry) {
                  ProgramEntry pe = (ProgramEntry)entry;
                  if (pe.name.toLowerCase().contains(query)) {
                     this.addProgramButton(pe);
                  }
               }
            }
         }
      }

      this.buttonPanel.revalidate();
      this.buttonPanel.repaint();
   }

   private void addCategory(String text) {
      JLabel label = new JLabel(text);
      label.setFont(label.getFont().deriveFont(1, 13.0F));
      label.setAlignmentX(0.5F);
      this.buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
      this.buttonPanel.add(label);
      this.buttonPanel.add(Box.createRigidArea(new Dimension(0, 5)));
   }

   private void addLabel(String text) {
      JLabel label = new JLabel(text);
      label.setFont(label.getFont().deriveFont(1, 13.0F));
      label.setAlignmentX(0.5F);
      this.buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
      this.buttonPanel.add(label);
      this.buttonPanel.add(Box.createRigidArea(new Dimension(0, 5)));
   }

   private void addProgramButton(final ProgramEntry pe) {
      JButton button = new JButton(pe.name);
      button.setAlignmentX(0.5F);
      if (pe.icon != null) {
         button.setIcon(pe.icon);
      }

      button.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            ProgramLauncher.this.launchProgram(pe.path);
            ProgramLauncher.this.dispose();
         }
      });
      this.buttonPanel.add(button);
      this.buttonPanel.add(Box.createRigidArea(new Dimension(0, 5)));
   }

   private void loadConfig() {
      try {
         File jarFile = new File(this.getClass().getProtectionDomain().getCodeSource().getLocation().toURI());
         File configFile = new File(jarFile.getParentFile(), "config.cfg");
         BufferedReader reader = new BufferedReader(new FileReader(configFile));
         String name = null;
         String path = null;
         String iconPath = null;
         GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
         Rectangle usableBounds = ge.getMaximumWindowBounds();

         while(true) {
            while(true) {
               String line;
               do {
                  if ((line = reader.readLine()) == null) {
                     if (name != null && path != null) {
                        this.entries.add(new ProgramEntry(name, path, iconPath));
                     }

                     reader.close();
                     return;
                  }

                  line = line.trim();
               } while(line.isEmpty());

               String val;
               if (line.startsWith("ResW=")) {
                  val = line.substring(5).replace("\"", "").trim();
                  this.windowWidth = val.equalsIgnoreCase("max") ? (int)usableBounds.getWidth() : Integer.parseInt(val);
               } else if (line.startsWith("ResH=")) {
                  val = line.substring(5).replace("\"", "").trim();
                  this.windowHeight = val.equalsIgnoreCase("max") ? (int)usableBounds.getHeight() : Integer.parseInt(val);
               } else if (line.startsWith("%*") && line.endsWith("*%")) {
                  if (name != null && path != null) {
                     this.entries.add(new ProgramEntry(name, path, iconPath));
                  }

                  name = null;
                  path = null;
                  iconPath = null;
                  this.entries.add(new LabelEntry(line.substring(2, line.length() - 2).trim()));
               } else if (line.startsWith("%") && line.endsWith("%")) {
                  if (name != null && path != null) {
                     this.entries.add(new ProgramEntry(name, path, iconPath));
                  }

                  name = null;
                  path = null;
                  iconPath = null;
                  this.entries.add(new CategoryEntry(line.substring(1, line.length() - 1).trim()));
               } else if (!line.contains("=")) {
                  if (name != null && path != null) {
                     this.entries.add(new ProgramEntry(name, path, iconPath));
                  }

                  name = line;
                  path = null;
                  iconPath = null;
               } else if (line.startsWith("Path=")) {
                  path = line.substring(5).replace("\"", "").trim();
               } else if (line.startsWith("Icon=")) {
                  iconPath = line.substring(5).replace("\"", "").trim();
               }
            }
         }
      } catch (Exception var11) {
         JOptionPane.showMessageDialog(this, "Failed to load config.cfg: " + var11.getMessage());
      }
   }

   private void buildButtons() {
      this.buttonPanel.removeAll();

      for(int i = 0; i < this.entries.size(); ++i) {
         LauncherEntry entry = (LauncherEntry)this.entries.get(i);
         if (entry instanceof LabelEntry) {
            this.addLabel(((LabelEntry)entry).label);
         } else if (entry instanceof ProgramEntry) {
            this.addProgramButton((ProgramEntry)entry);
         } else if (entry instanceof CategoryEntry) {
            this.addCategory(((CategoryEntry)entry).category);
         }
      }

      this.buttonPanel.revalidate();
      this.buttonPanel.repaint();
   }

   private void launchProgram(String path) {
      try {
         File exe = new File(path);
         if (!exe.exists()) {
            JOptionPane.showMessageDialog(this, "File does not exist: " + path);
            return;
         }

         (new ProcessBuilder(new String[]{exe.getAbsolutePath()})).start();
      } catch (IOException var3) {
         JOptionPane.showMessageDialog(this, "Unable to launch the program: " + var3.getMessage());
      }

   }

   public static class CategoryEntry implements LauncherEntry {
      String category;

      CategoryEntry(String category) {
         this.category = category;
      }
   }

   public static class LabelEntry implements LauncherEntry {
      String label;

      LabelEntry(String label) {
         this.label = label;
      }
   }

   public interface LauncherEntry {
   }

   public static class ProgramEntry implements LauncherEntry {
      String name;
      String path;
      Icon icon;

      ProgramEntry(String name, String path, String iconPath) {
         this.name = name;
         this.path = path;
         this.icon = getProgramIcon(path, iconPath);
      }

      private static Icon getProgramIcon(String exePath, String iconPath) {
         try {
            File file;
            Image icoImage;
            if (iconPath != null && !iconPath.isEmpty()) {
               file = new File(iconPath);
               if (file.exists()) {
                  String lower = iconPath.toLowerCase();
                  if (lower.endsWith(".gif")) {
                     ImageIcon gifIcon = new ImageIcon(iconPath);
                     icoImage = gifIcon.getImage().getScaledInstance(24, 24, 1);
                     return new ImageIcon(icoImage);
                  }

                  if (lower.endsWith(".png")) {
                     BufferedImage img = ImageIO.read(file);
                     if (img != null) {
                        icoImage = img.getScaledInstance(24, 24, 4);
                        return new ImageIcon(icoImage);
                     }
                  }

                  if (lower.endsWith(".ico") || lower.endsWith(".exe")) {
                     ShellFolder sf = ShellFolder.getShellFolder(file);
                     icoImage = sf.getIcon(true);
                     return new ImageIcon(icoImage.getScaledInstance(24, 24, 4));
                  }
               }
            }

            file = new File(exePath);
            ShellFolder sf = ShellFolder.getShellFolder(file);
            icoImage = sf.getIcon(true);
            return new ImageIcon(icoImage.getScaledInstance(24, 24, 4));
         } catch (Exception var6) {
            System.err.println("Error while loading icon: " + var6.getMessage());
            return null;
         }
      }
   }
}
