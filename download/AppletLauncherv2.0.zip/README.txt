  __      __            _     _____ _________  ____   ___        _ _   _           _      _       
  \ \    / /           | |   / ____|___  /__ \|___ \ / _ \      (_) | | |         | |    (_)      
   \ \  / /_ _ ___  ___| | _| |       / /   ) | __) | | | | __ _ _| |_| |__  _   _| |__   _  ___  
    \ \/ / _` / __|/ _ \ |/ / |      / /   / / |__ <| | | |/ _` | | __| '_ \| | | | '_ \ | |/ _ \ 
     \  / (_| \__ \  __/   <| |____ / /__ / /_ ___) | |_| | (_| | | |_| | | | |_| | |_) || | (_) |
      \/ \__,_|___/\___|_|\_\\_____/_____|____|____/ \___(_)__, |_|\__|_| |_|\__,_|_.__(_)_|\___/ 
                                                            __/ |                                 
                                                           |___/

========================================
AppletViewer v2.0 Manual
========================================

Overview
--------
AppletViewer v2.0 is a Java program that allows you to run Java Applets 
either via a Graphical User Interface (GUI) or Command-Line Interface (CLI).

It supports:
- Loading .class or .jar applets
- Passing parameters to applets
- Manual or automatic window size
- Network access control
- Console output for debugging

----------------------------------------
GUI Usage
----------------------------------------
1. Run the program:
   - Double-click the appletviewer2.0.jar or use this command: java -jar appletviewerv2.0.jar

2. GUI Overview:

   Menu Tab:
   - Applet Parameters: Enter key=value pairs, one per line.
   - Manual Resolution: Check to set custom width and height.
   - Width/Height: Set applet window size if manual resolution is checked.
   - Network Mode:
       manual - asks before connecting to a URL
       true   - allows all network connections
       false  - denies all network connections
   - Select Class/JAR: Choose a .class file or .jar file.
   - Launch Applet: Starts the selected applet. Previous applets are automatically stopped.
   - File Indicator: Shows currently loaded file.

   Console Tab:
   - Displays System.out and System.err from the applet.

3. After launching an applet, the menu resets for the next applet.

----------------------------------------
CLI Usage
----------------------------------------
You can also run Applets without using the GUI.

Syntax:
java -jar appletviewerv2.0.jar [file] [className] [params] [network] [width] [height]

Arguments:
file       - Path to .class or .jar file. Required.

className  - Full class name of the applet (including package if in jar). 
             Optional for single .class files; required for .jar files with multiple classes.
			 
params     - Applet parameters as key=value pairs separated by semicolons (;). Optional.
             Example: foo=1;bar=2
			 
network    - Network access mode. Optional. Default: manual.
             Options: manual, true, false
			 
width      - Window width. Optional. Default: 800

height     - Window height. Optional. Default: 600

Examples:
1. Load a .class file with default settings:
   java -jar appletviewerv2.0.jar MyApplet.class

2. Load a .jar file with a specific class and parameters:
   java -jar appletviewerv2.0.jar myApplet.jar com.example.MyApplet foo=1;bar=2 true 1024 768

3. Load a .jar with manual network mode and custom size:
   java -jar appletviewerv2.0.jar myApplet.jar MyApplet width=640;height=480 manual 640 480

----------------------------------------
Notes
----------------------------------------
- GUI and CLI versions share the same engine; behavior is identical.
- When using the CLI, the GUI window still appears, but the applet loads automatically.
- Only one applet runs at a time. Loading a new one stops the previous.
- The console tab displays all output from the applet.
