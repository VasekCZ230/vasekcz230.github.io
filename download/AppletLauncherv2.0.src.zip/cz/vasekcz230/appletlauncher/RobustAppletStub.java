package cz.vasekcz230.appletlauncher;

import java.applet.Applet;
import java.applet.AppletContext;
import java.applet.AppletStub;
import java.applet.AudioClip;
import java.awt.Desktop;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

class RobustAppletStub implements AppletStub {
   private Applet applet;
   private File file;
   private Map parameters;
   private AppletLauncher.NetworkMode networkMode;
   private JFrame frame;

   public RobustAppletStub(Applet applet, File file, Map parameters, AppletLauncher.NetworkMode networkMode, JFrame frame) {
      this.applet = applet;
      this.file = file;
      this.parameters = (Map)(parameters != null ? parameters : new HashMap());
      this.networkMode = networkMode;
      this.frame = frame;
   }

   public boolean isActive() {
      return true;
   }

   public URL getDocumentBase() {
      try {
         return this.file.isDirectory() ? this.file.toURI().toURL() : this.file.getParentFile().toURI().toURL();
      } catch (Exception var2) {
         return null;
      }
   }

   public URL getCodeBase() {
      try {
         return this.file.isDirectory() ? this.file.toURI().toURL() : this.file.getParentFile().toURI().toURL();
      } catch (Exception var2) {
         return null;
      }
   }

   public String getParameter(String name) {
      return (String)this.parameters.get(name);
   }

   public AppletContext getAppletContext() {
      final JFrame f = this.frame;
      return new AppletContext() {
         public AudioClip getAudioClip(URL url) {
            return null;
         }

         public Image getImage(URL url) {
            return null;
         }

         public Applet getApplet(String name) {
            return null;
         }

         public Enumeration getApplets() {
            return (new Vector()).elements();
         }

         public void showDocument(final URL url) {
            if (RobustAppletStub.this.networkMode != AppletLauncher.NetworkMode.FALSE) {
               if (RobustAppletStub.this.networkMode == AppletLauncher.NetworkMode.TRUE) {
                  try {
                     Desktop.getDesktop().browse(url.toURI());
                  } catch (Exception var3) {
                     var3.printStackTrace();
                  }
               }

               if (RobustAppletStub.this.networkMode == AppletLauncher.NetworkMode.MANUAL) {
                  SwingUtilities.invokeLater(new Runnable() {
                     public void run() {
                        int r = JOptionPane.showConfirmDialog(f, "The applet is attempting to connect to the domain: " + url.getHost() + "\nDo you want to allow the connection?", "Network connection", 0);
                        if (r == 0) {
                           try {
                              Desktop.getDesktop().browse(url.toURI());
                           } catch (Exception var3) {
                              var3.printStackTrace();
                           }
                        }

                     }
                  });
               }

            }
         }

         public void showDocument(URL url, String target) {
            this.showDocument(url);
         }

         public void showStatus(String status) {
            System.out.println(status);
         }

         public void setStream(String key, InputStream stream) throws IOException {
         }

         public InputStream getStream(String key) {
            return null;
         }

         public Iterator getStreamKeys() {
            return (new Vector()).iterator();
         }
      };
   }

   public void appletResize(int width, int height) {
      if (this.frame != null) {
         this.frame.setSize(width, height);
      }

   }
}
