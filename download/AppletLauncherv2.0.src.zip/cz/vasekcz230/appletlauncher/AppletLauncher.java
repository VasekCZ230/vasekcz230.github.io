package cz.vasekcz230.appletlauncher;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class AppletLauncher {
   private JFrame frame;
   private JTabbedPane tabbedPane;
   private JTextArea consoleArea;
   private JPanel menuPanel;
   private JLabel loadedFileLabel;
   private JTextArea paramField;
   private JCheckBox manualResCheck;
   private JSpinner widthSpin;
   private JSpinner heightSpin;
   private JComboBox networkBox;
   private Applet currentApplet;
   private File loadedFile;
   private String loadedClass;

   public static void main(final String[] args) {
      final AppletLauncher viewer = new AppletLauncher();
      viewer.createAndShowGUI();
      if (args.length >= 1) {
         SwingUtilities.invokeLater(new Runnable() {
            public void run() {
               File file = new File(args[0]);
               String className = args.length >= 2 ? args[1] : null;
               Map params = new HashMap();
               int h;
               if (args.length >= 3) {
                  String[] pairs = args[2].split(";");
                  String[] var8 = pairs;
                  int var7 = pairs.length;

                  for(h = 0; h < var7; ++h) {
                     String p = var8[h];
                     String[] kv = p.split("=");
                     if (kv.length == 2) {
                        params.put(kv[0].trim(), kv[1].trim());
                     }
                  }
               }

               NetworkMode netMode = AppletLauncher.NetworkMode.MANUAL;
               if (args.length >= 4) {
                  try {
                     netMode = AppletLauncher.NetworkMode.valueOf(args[3].toUpperCase());
                  } catch (Exception var11) {
                  }
               }

               int w = 800;
               h = 600;
               if (args.length >= 6) {
                  try {
                     w = Integer.parseInt(args[4]);
                     h = Integer.parseInt(args[5]);
                  } catch (Exception var10) {
                  }
               }

               viewer.loadedFile = file;
               viewer.loadedClass = className != null ? className : viewer.getClassNameFromFile(file);
               viewer.loadedFileLabel.setText("Loaded: " + file.getName());
               if (viewer.currentApplet != null) {
                  Component oldPanel = viewer.currentApplet.getParent();
                  viewer.currentApplet.stop();
                  viewer.currentApplet.destroy();
                  viewer.currentApplet = null;
                  if (oldPanel != null) {
                     viewer.tabbedPane.remove(oldPanel);
                     viewer.tabbedPane.revalidate();
                     viewer.tabbedPane.repaint();
                  }
               }

               viewer.loadApplet(viewer.loadedFile, viewer.loadedClass, params, netMode, w, h, true);
            }
         });
      }

   }

   public void createAndShowGUI() {
      this.frame = new JFrame("Applet Launcher v2.0");
      this.frame.setDefaultCloseOperation(3);
      this.frame.setSize(500, 400);
      this.frame.setLayout(new BorderLayout());
      this.frame.setLocationRelativeTo((Component)null);
      this.tabbedPane = new JTabbedPane();
      this.frame.add(this.tabbedPane, "Center");
      this.createMenuTab();
      this.createConsoleTab();
      this.tabbedPane.addChangeListener(new ChangeListener() {
         private int lastIndex = -1;

         public void stateChanged(ChangeEvent e) {
            int idx = AppletLauncher.this.tabbedPane.getSelectedIndex();
            if (this.lastIndex != -1 && this.lastIndex != idx) {
               AppletLauncher.this.stopApplet(AppletLauncher.this.tabbedPane.getComponentAt(this.lastIndex));
            }

            Component comp = AppletLauncher.this.tabbedPane.getComponentAt(idx);
            if (comp instanceof JPanel) {
               JPanel p = (JPanel)comp;
               Component[] var8;
               int var7 = (var8 = p.getComponents()).length;

               for(int var6 = 0; var6 < var7; ++var6) {
                  Component c = var8[var6];
                  if (c instanceof Applet) {
                     AppletLauncher.this.currentApplet = (Applet)c;
                     Dimension d = AppletLauncher.this.currentApplet.getPreferredSize();
                     if (d != null) {
                        AppletLauncher.this.frame.setSize(d.width + 20, d.height + 60);
                     }

                     AppletLauncher.this.currentApplet.start();
                     break;
                  }
               }
            }

            this.lastIndex = idx;
         }
      });
      this.frame.setVisible(true);
   }

   private void stopApplet(Component comp) {
      if (comp instanceof JPanel) {
         JPanel p = (JPanel)comp;
         Component[] var6;
         int var5 = (var6 = p.getComponents()).length;

         for(int var4 = 0; var4 < var5; ++var4) {
            Component c = var6[var4];
            if (c instanceof Applet) {
               ((Applet)c).stop();
               ((Applet)c).destroy();
            }
         }
      }

   }

   private void createMenuTab() {
      this.menuPanel = new JPanel();
      this.menuPanel.setLayout(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.fill = 2;
      gbc.insets = new Insets(5, 5, 5, 5);
      JLabel label = new JLabel("Applet Parameters (key=value per line):");
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.gridwidth = 2;
      this.menuPanel.add(label, gbc);
      this.paramField = new JTextArea(5, 25);
      this.paramField.setLineWrap(true);
      this.paramField.setWrapStyleWord(true);
      JScrollPane paramScroll = new JScrollPane(this.paramField);
      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 2;
      this.menuPanel.add(paramScroll, gbc);
      JPanel sizePanel = new JPanel(new FlowLayout(1, 5, 0));
      sizePanel.add(new JLabel("Width:"));
      this.widthSpin = new JSpinner(new SpinnerNumberModel(800, 100, 5000, 1));
      this.widthSpin.setPreferredSize(new Dimension(60, 20));
      sizePanel.add(this.widthSpin);
      sizePanel.add(new JLabel("Height:"));
      this.heightSpin = new JSpinner(new SpinnerNumberModel(600, 100, 5000, 1));
      this.heightSpin.setPreferredSize(new Dimension(60, 20));
      sizePanel.add(this.heightSpin);
      this.manualResCheck = new JCheckBox("Manual Resolution");
      sizePanel.add(this.manualResCheck);
      gbc.gridx = 0;
      gbc.gridy = 2;
      gbc.gridwidth = 2;
      this.menuPanel.add(sizePanel, gbc);
      JPanel networkPanel = new JPanel(new FlowLayout(1, 5, 0));
      networkPanel.add(new JLabel("Network Mode:"));
      this.networkBox = new JComboBox(new String[]{"Manual", "Enabled", "Disabled"});
      networkPanel.add(this.networkBox);
      gbc.gridx = 0;
      gbc.gridy = 3;
      gbc.gridwidth = 2;
      this.menuPanel.add(networkPanel, gbc);
      JButton selectAppletButton = new JButton("Select Class/JAR");
      JButton launchButton = new JButton("Launch Applet");
      this.loadedFileLabel = new JLabel("No file loaded");
      JPanel buttonPanel = new JPanel(new FlowLayout(1, 5, 0));
      buttonPanel.add(selectAppletButton);
      buttonPanel.add(launchButton);
      buttonPanel.add(this.loadedFileLabel);
      gbc.gridx = 0;
      gbc.gridy = 4;
      gbc.gridwidth = 2;
      this.menuPanel.add(buttonPanel, gbc);
      this.tabbedPane.addTab("Menu", this.menuPanel);
      selectAppletButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select Class/JAR");
            chooser.setFileSelectionMode(2);
            int res = chooser.showOpenDialog(AppletLauncher.this.frame);
            if (res == 0) {
               File file = chooser.getSelectedFile();
               if (file.isDirectory()) {
                  JOptionPane.showMessageDialog(AppletLauncher.this.frame, "Select a .class or .jar file, not a folder.");
                  return;
               }

               if (!file.getName().toLowerCase().endsWith(".class") && !file.getName().toLowerCase().endsWith(".jar")) {
                  JOptionPane.showMessageDialog(AppletLauncher.this.frame, "Not a .class or .jar file.");
                  return;
               }

               AppletLauncher.this.loadedFile = file;
               if (file.getName().toLowerCase().endsWith(".class")) {
                  AppletLauncher.this.loadedClass = AppletLauncher.this.getClassNameFromFile(file);
               } else if (file.getName().toLowerCase().endsWith(".jar")) {
                  AppletLauncher.this.loadedClass = AppletLauncher.this.selectClassFromJar(file);
               }

               AppletLauncher.this.loadedFileLabel.setText("Loaded: " + file.getName());
            }

         }
      });
      launchButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            if (AppletLauncher.this.loadedFile != null && AppletLauncher.this.loadedClass != null) {
               final Map params = AppletLauncher.this.parseAppletParamsMultiLine(AppletLauncher.this.paramField.getText());
               final boolean manualRes = AppletLauncher.this.manualResCheck.isSelected();
               final int w = (Integer)AppletLauncher.this.widthSpin.getValue();
               final int h = (Integer)AppletLauncher.this.heightSpin.getValue();
               final NetworkMode netMode = AppletLauncher.NetworkMode.valueOf(((String)AppletLauncher.this.networkBox.getSelectedItem()).toUpperCase());
               if (AppletLauncher.this.currentApplet != null) {
                  Component oldPanel = AppletLauncher.this.currentApplet.getParent();
                  AppletLauncher.this.currentApplet.stop();
                  AppletLauncher.this.currentApplet.destroy();
                  AppletLauncher.this.currentApplet = null;
                  if (oldPanel != null) {
                     AppletLauncher.this.tabbedPane.remove(oldPanel);
                     AppletLauncher.this.tabbedPane.revalidate();
                     AppletLauncher.this.tabbedPane.repaint();
                  }
               }

               final File fileToLoad = AppletLauncher.this.loadedFile;
               final String classToLoad = AppletLauncher.this.loadedClass;
               SwingUtilities.invokeLater(new Runnable() {
                  public void run() {
                     AppletLauncher.this.loadApplet(fileToLoad, classToLoad, params, netMode, w, h, manualRes);
                     AppletLauncher.this.paramField.setText("");
                     AppletLauncher.this.manualResCheck.setSelected(false);
                     AppletLauncher.this.widthSpin.setValue(800);
                     AppletLauncher.this.heightSpin.setValue(600);
                     AppletLauncher.this.networkBox.setSelectedItem("Manual");
                  }
               });
            } else {
               JOptionPane.showMessageDialog(AppletLauncher.this.frame, "Select a file first!");
            }
         }
      });
   }

   private Map parseAppletParamsMultiLine(String input) {
      Map map = new HashMap();
      if (input != null && !input.trim().isEmpty()) {
         String[] lines = input.split("\\r?\\n");
         String[] var7 = lines;
         int var6 = lines.length;

         for(int var5 = 0; var5 < var6; ++var5) {
            String line = var7[var5];
            String[] kv = line.split("=");
            if (kv.length == 2) {
               map.put(kv[0].trim(), kv[1].trim());
            }
         }
      }

      return map;
   }

   private void createConsoleTab() {
      this.consoleArea = new JTextArea();
      this.consoleArea.setEditable(false);
      JScrollPane scroll = new JScrollPane(this.consoleArea);
      this.tabbedPane.addTab("Console", scroll);
      PrintStream ps = new PrintStream(new OutputStream() {
         public void write(int b) throws IOException {
            AppletLauncher.this.consoleArea.append(String.valueOf((char)b));
            AppletLauncher.this.consoleArea.setCaretPosition(AppletLauncher.this.consoleArea.getDocument().getLength());
         }
      });
      System.setOut(ps);
      System.setErr(ps);
   }

   private void loadApplet(File file, String className, Map params, NetworkMode netMode, int width, int height, boolean manualRes) {
      try {
         JPanel panel = new JPanel(new BorderLayout());
         URL[] urls;
         if (file.getName().toLowerCase().endsWith(".jar")) {
            urls = new URL[]{file.toURI().toURL()};
         } else {
            urls = new URL[]{file.getParentFile().toURI().toURL()};
         }

         URLClassLoader loader = new URLClassLoader(urls, this.getClass().getClassLoader());
         Class appClass = Class.forName(className, true, loader);
         Applet applet = (Applet)appClass.getDeclaredConstructor().newInstance();
         this.currentApplet = applet;
         applet.setStub(new RobustAppletStub(applet, file, params, netMode, this.frame));
         applet.init();
         Dimension d = applet.getPreferredSize();
         if (manualRes) {
            applet.setSize(width, height);
            panel.setPreferredSize(new Dimension(width, height));
            this.frame.setSize(width + 20, height + 60);
         } else if (d != null) {
            applet.setSize(d);
            panel.setPreferredSize(d);
            this.frame.setSize(d.width + 20, d.height + 60);
         } else {
            applet.setSize(800, 600);
            panel.setPreferredSize(new Dimension(800, 600));
            this.frame.setSize(820, 660);
         }

         panel.add(applet, "Center");
         this.tabbedPane.addTab(className, panel);
         this.tabbedPane.setSelectedComponent(panel);
      } catch (Exception var14) {
         var14.printStackTrace();
         this.appendToConsole("Error loading applet: " + var14.getMessage());
      }

   }

   private String selectClassFromJar(File jarFile) {
      try {
         JarFile jar = new JarFile(jarFile);
         Enumeration entries = jar.entries();
         ArrayList classNames = new ArrayList();

         while(entries.hasMoreElements()) {
            JarEntry entry = (JarEntry)entries.nextElement();
            if (entry.getName().endsWith(".class")) {
               String name = entry.getName().replace("/", ".").replace(".class", "");
               classNames.add(name);
            }
         }

         jar.close();
         if (!classNames.isEmpty()) {
            return (String)JOptionPane.showInputDialog(this.frame, "Select Applet Class:", "Classes", -1, (Icon)null, classNames.toArray(), classNames.get(0));
         }
      } catch (Exception var7) {
         var7.printStackTrace();
      }

      return null;
   }

   private String getClassNameFromFile(File classFile) {
      String name = classFile.getName();
      return name.endsWith(".class") ? name.substring(0, name.length() - 6) : name;
   }

   private void appendToConsole(String msg) {
      this.consoleArea.append(msg + "\n");
      this.consoleArea.setCaretPosition(this.consoleArea.getDocument().getLength());
   }

   public static enum NetworkMode {
      MANUAL,
      TRUE,
      FALSE;
   }
}
