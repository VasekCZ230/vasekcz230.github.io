package cz.vasekcz230.prismlauncherofflineaccountmanager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.UUID;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;

public class PrismLauncherOfflineAccountManager extends JFrame {
   private JTextField filePathField;
   private JButton browseButton;
   private JButton addOfflineBtn;
   private JButton addMicrosoftBtn;
   private JButton removeSelectedBtn;
   private JLabel LegacyAccountInfo;
   private JTextField nickField;
   private DefaultListModel accountsListModel;
   private JList accountsList;
   private File accountsFile;
   private JsonObject rootJson;

   public PrismLauncherOfflineAccountManager() {
      super("Prism Launcher Offline Account Manager v2.2.0");
      this.setDefaultCloseOperation(3);
      this.setSize(785, 550);
      this.setLocationRelativeTo((Component)null);
      this.initComponents();
      this.layoutComponents();
      this.attachListeners();
   }

   private void initComponents() {
      this.filePathField = new JTextField(40);
      this.filePathField.setEditable(false);
      this.browseButton = new JButton("Select or Create accounts.json");
      this.addOfflineBtn = new JButton("Add Offline Account");
      this.addMicrosoftBtn = new JButton("Add Empty Microsoft Account");
      this.removeSelectedBtn = new JButton("Delete Selected Account");
      this.LegacyAccountInfo = new JLabel("(An empty Microsoft account is required in some Prism Launcher versions, but won't work with others.)");
      this.addOfflineBtn.setEnabled(false);
      this.addMicrosoftBtn.setEnabled(false);
      this.removeSelectedBtn.setEnabled(false);
      this.accountsListModel = new DefaultListModel();
      this.accountsList = new JList(this.accountsListModel);
      this.accountsList.setSelectionMode(0);
      this.accountsList.setCellRenderer(new AccountListCellRenderer());
   }

   private void layoutComponents() {
      JPanel topPanel = new JPanel(new FlowLayout(1));
      topPanel.add(new JLabel("accounts.json file:"));
      topPanel.add(this.filePathField);
      JPanel buttonsPanel = new JPanel(new FlowLayout(1, 10, 5));
      buttonsPanel.add(this.browseButton);
      buttonsPanel.add(this.addOfflineBtn);
      buttonsPanel.add(this.addMicrosoftBtn);
      buttonsPanel.add(this.removeSelectedBtn);
      buttonsPanel.add(this.LegacyAccountInfo);
      JScrollPane scrollPane = new JScrollPane(this.accountsList);
      scrollPane.setPreferredSize(new Dimension(730, 420));
      Container cp = this.getContentPane();
      cp.setLayout(new BorderLayout(5, 5));
      cp.add(topPanel, "North");
      cp.add(buttonsPanel, "Center");
      cp.add(scrollPane, "South");
   }

   private void attachListeners() {
      this.browseButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            JFileChooser chooser = new JFileChooser();
            chooser.setSelectedFile(new File("accounts.json"));
            chooser.setDialogTitle("Select accounts.json");
            chooser.setFileFilter(new FileNameExtensionFilter("JSON files", new String[]{"json"}));
            int ret = chooser.showOpenDialog(PrismLauncherOfflineAccountManager.this);
            if (ret == 0) {
               File selectedFile = chooser.getSelectedFile();
               if (!selectedFile.exists()) {
                  int createConfirm = JOptionPane.showConfirmDialog(PrismLauncherOfflineAccountManager.this, "File does not exist. Do you want to create it?", "Create File?", 0);
                  if (createConfirm != 0) {
                     return;
                  }

                  PrismLauncherOfflineAccountManager.this.accountsFile = selectedFile;
                  PrismLauncherOfflineAccountManager.this.createEmptyAccountsFile();
                  PrismLauncherOfflineAccountManager.this.filePathField.setText(PrismLauncherOfflineAccountManager.this.accountsFile.getAbsolutePath());
                  PrismLauncherOfflineAccountManager.this.loadAccountsFile();
               } else {
                  PrismLauncherOfflineAccountManager.this.accountsFile = selectedFile;
                  PrismLauncherOfflineAccountManager.this.filePathField.setText(PrismLauncherOfflineAccountManager.this.accountsFile.getAbsolutePath());
                  PrismLauncherOfflineAccountManager.this.loadAccountsFile();
               }
            }

         }
      });
      this.addOfflineBtn.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            if (PrismLauncherOfflineAccountManager.this.accountsFile == null) {
               JOptionPane.showMessageDialog(PrismLauncherOfflineAccountManager.this, "Please select an accounts.json file first.");
            } else {
               String nick = JOptionPane.showInputDialog(PrismLauncherOfflineAccountManager.this, "Enter offline account nickname:", "Add Offline Account", -1);
               if (nick != null) {
                  nick = nick.trim();
                  if (!nick.isEmpty()) {
                     PrismLauncherOfflineAccountManager.this.addOfflineAccount(nick);
                  } else {
                     JOptionPane.showMessageDialog(PrismLauncherOfflineAccountManager.this, "Nickname cannot be empty.");
                  }
               }
            }

         }
      });
      this.addMicrosoftBtn.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            if (PrismLauncherOfflineAccountManager.this.accountsFile == null) {
               JOptionPane.showMessageDialog(PrismLauncherOfflineAccountManager.this, "Please select an accounts.json file first.");
            } else {
               PrismLauncherOfflineAccountManager.this.addMicrosoftAccount();
            }

         }
      });
      this.removeSelectedBtn.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            AccountEntry selected = (AccountEntry)PrismLauncherOfflineAccountManager.this.accountsList.getSelectedValue();
            if (selected != null) {
               int confirm = JOptionPane.showConfirmDialog(PrismLauncherOfflineAccountManager.this, "Are you sure you want to delete the account: " + selected.nick + " (" + selected.type + ")?", "Confirm Deletion", 0);
               if (confirm == 0) {
                  PrismLauncherOfflineAccountManager.this.removeAccount(selected);
               }
            }

         }
      });
      this.accountsList.addListSelectionListener(new ListSelectionListener() {
         public void valueChanged(ListSelectionEvent e) {
            AccountEntry selected = (AccountEntry)PrismLauncherOfflineAccountManager.this.accountsList.getSelectedValue();
            PrismLauncherOfflineAccountManager.this.removeSelectedBtn.setEnabled(selected != null);
         }
      });
   }

   private void loadAccountsFile() {
      if (this.accountsFile != null && this.accountsFile.exists()) {
         try {
            Throwable var1 = null;
            Object var2 = null;

            try {
               InputStreamReader reader = new InputStreamReader(new FileInputStream(this.accountsFile), StandardCharsets.UTF_8);

               try {
                  JsonParser parser = new JsonParser();
                  this.rootJson = parser.parse((Reader)reader).getAsJsonObject();
                  if (!this.rootJson.has("formatVersion") || this.rootJson.get("formatVersion").getAsInt() != 3) {
                     JOptionPane.showMessageDialog(this, "Unsupported accounts.json format (formatVersion is not 3).");
                     this.rootJson = null;
                     this.accountsListModel.clear();
                     this.disableAddButtons();
                     return;
                  }

                  JsonArray arr = this.rootJson.getAsJsonArray("accounts");
                  this.accountsListModel.clear();
                  Iterator var7 = arr.iterator();

                  while(var7.hasNext()) {
                     JsonElement el = (JsonElement)var7.next();
                     JsonObject o = el.getAsJsonObject();
                     AccountEntry acc = PrismLauncherOfflineAccountManager.AccountEntry.fromJsonObject(o);
                     this.accountsListModel.addElement(acc);
                  }

                  this.enableAddButtons();
                  return;
               } finally {
                  if (reader != null) {
                     reader.close();
                  }

               }
            } catch (Throwable var17) {
               if (var1 == null) {
                  var1 = var17;
               } else if (var1 != var17) {
                  var1.addSuppressed(var17);
               }

               throw var1;
            }
         } catch (Exception var18) {
            JOptionPane.showMessageDialog(this, "Error loading file: " + var18.getMessage());
            this.rootJson = null;
            this.accountsListModel.clear();
            this.disableAddButtons();
         }
      } else {
         JOptionPane.showMessageDialog(this, "Please select a valid accounts.json file.");
      }

   }

   private void enableAddButtons() {
      this.addOfflineBtn.setEnabled(true);
      this.addMicrosoftBtn.setEnabled(true);
   }

   private void disableAddButtons() {
      this.addOfflineBtn.setEnabled(false);
      this.addMicrosoftBtn.setEnabled(false);
   }

   private void saveAccountsFile() {
      if (this.accountsFile != null && this.rootJson != null) {
         JsonArray arr = new JsonArray();

         AccountEntry acc;
         for(int i = 0; i < this.accountsListModel.size(); ++i) {
            acc = (AccountEntry)this.accountsListModel.get(i);
            arr.add((JsonElement)acc.toJsonObject());
         }

         this.rootJson.add("accounts", arr);

         try {
            Throwable var15 = null;
            acc = null;

            try {
               OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(this.accountsFile), StandardCharsets.UTF_8);

               try {
                  Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
                  gson.toJson((JsonElement)this.rootJson, (Appendable)writer);
               } finally {
                  if (writer != null) {
                     writer.close();
                  }

               }
            } catch (Throwable var13) {
               if (var15 == null) {
                  var15 = var13;
               } else if (var15 != var13) {
                  var15.addSuppressed(var13);
               }

               throw var15;
            }
         } catch (Exception var14) {
            JOptionPane.showMessageDialog(this, "Error saving file: " + var14.getMessage());
         }
      }

   }

   private void createEmptyAccountsFile() {
      this.rootJson = new JsonObject();
      this.rootJson.addProperty("formatVersion", (int)3);
      JsonArray arr = new JsonArray();
      JsonObject legacyEmpty = this.createEmptyLegacyAccountJson();
      arr.add((JsonElement)legacyEmpty);
      this.rootJson.add("accounts", arr);

      try {
         Throwable var3 = null;
         Object var4 = null;

         try {
            OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(this.accountsFile), StandardCharsets.UTF_8);

            try {
               Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
               gson.toJson((JsonElement)this.rootJson, (Appendable)writer);
               JOptionPane.showMessageDialog(this, "File created.");
            } finally {
               if (writer != null) {
                  writer.close();
               }

            }
         } catch (Throwable var14) {
            if (var3 == null) {
               var3 = var14;
            } else if (var3 != var14) {
               var3.addSuppressed(var14);
            }

            throw var3;
         }
      } catch (Exception var15) {
         JOptionPane.showMessageDialog(this, "Error creating file: " + var15.getMessage());
      }

   }

   private void addOfflineAccount(String nick) {
      if (!nick.isEmpty()) {
         for(int i = 0; i < this.accountsListModel.size(); ++i) {
            AccountEntry acc = (AccountEntry)this.accountsListModel.get(i);
            if ("Offline".equals(acc.type) && nick.equals(acc.nick)) {
               JOptionPane.showMessageDialog(this, "Offline account with this nickname already exists.");
               return;
            }
         }

         AccountEntry newAcc = PrismLauncherOfflineAccountManager.AccountEntry.createOffline(nick);
         this.accountsListModel.addElement(newAcc);
         this.saveAccountsFile();
         this.loadAccountsFile();
      }

   }

   private void addMicrosoftAccount() {
      for(int i = 0; i < this.accountsListModel.size(); ++i) {
         AccountEntry acc = (AccountEntry)this.accountsListModel.get(i);
         if ("MSA".equals(acc.type)) {
            JOptionPane.showMessageDialog(this, "Legacy empty account already exists.");
            return;
         }
      }

      AccountEntry legacy = PrismLauncherOfflineAccountManager.AccountEntry.createEmptyLegacy();
      this.accountsListModel.addElement(legacy);
      this.saveAccountsFile();
      this.loadAccountsFile();
   }

   private void removeAccount(AccountEntry acc) {
      this.accountsListModel.removeElement(acc);
      this.saveAccountsFile();
      this.loadAccountsFile();
   }

   private JsonObject createEmptyLegacyAccountJson() {
      JsonObject legacy = new JsonObject();
      JsonObject entitlement = new JsonObject();
      entitlement.addProperty("canPlayMinecraft", true);
      entitlement.addProperty("ownsMinecraft", true);
      legacy.add("entitlement", entitlement);
      legacy.addProperty("msa-client-id", "");
      legacy.addProperty("type", "MSA");
      return legacy;
   }

   public static void main(String[] args) {
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            PrismLauncherOfflineAccountManager manager = new PrismLauncherOfflineAccountManager();
            manager.setVisible(true);
         }
      });
   }

   private static class AccountEntry {
      String nick;
      String type;
      JsonObject fullJson;

      public AccountEntry(String nick, String type, JsonObject fullJson) {
         this.nick = nick;
         this.type = type;
         this.fullJson = fullJson;
      }

      static AccountEntry fromJsonObject(JsonObject o) {
         String type = o.has("type") ? o.get("type").getAsString() : "Unknown";
         String nick = "";
         if ("Offline".equals(type)) {
            if (o.has("profile") && o.get("profile").isJsonObject()) {
               JsonObject prof = o.get("profile").getAsJsonObject();
               if (prof.has("name")) {
                  nick = prof.get("name").getAsString();
               }
            }
         } else if ("MSA".equals(type)) {
            nick = "<Microsoft>";
         } else {
            nick = "<" + type + ">";
         }

         return new AccountEntry(nick, type, o);
      }

      JsonObject toJsonObject() {
         return this.fullJson.deepCopy().getAsJsonObject();
      }

      static AccountEntry createOffline(String nick) {
         JsonObject acc = new JsonObject();
         JsonObject profile = new JsonObject();
         profile.addProperty("id", createOfflineUUID(nick));
         profile.addProperty("name", nick);
         JsonObject skin = new JsonObject();
         skin.addProperty("id", "");
         skin.addProperty("url", "");
         skin.addProperty("variant", "");
         profile.add("capes", new JsonArray());
         profile.add("skin", skin);
         acc.add("profile", profile);
         acc.addProperty("type", "Offline");
         JsonObject ygg = new JsonObject();
         JsonObject extra = new JsonObject();
         extra.addProperty("clientToken", UUID.randomUUID().toString());
         extra.addProperty("userName", nick);
         ygg.add("extra", extra);
         ygg.addProperty("iat", (Number)(System.currentTimeMillis() / 1000L));
         ygg.addProperty("token", "0");
         acc.add("ygg", ygg);
         return new AccountEntry(nick, "Offline", acc);
      }

      static AccountEntry createEmptyLegacy() {
         JsonObject legacy = new JsonObject();
         JsonObject entitlement = new JsonObject();
         entitlement.addProperty("canPlayMinecraft", true);
         entitlement.addProperty("ownsMinecraft", true);
         legacy.add("entitlement", entitlement);
         legacy.addProperty("msa-client-id", "");
         legacy.addProperty("type", "MSA");
         return new AccountEntry("<Legacy>", "MSA", legacy);
      }

      private static String createOfflineUUID(String name) {
         try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hash).replaceFirst("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5");
         } catch (NoSuchAlgorithmException var3) {
            return UUID.randomUUID().toString();
         }
      }

      private static String bytesToHex(byte[] bytes) {
         StringBuilder sb = new StringBuilder();
         byte[] var5 = bytes;
         int var4 = bytes.length;

         for(int var3 = 0; var3 < var4; ++var3) {
            byte b = var5[var3];
            sb.append(String.format("%02x", b & 255));
         }

         return sb.toString();
      }
   }

   private static class AccountListCellRenderer extends JPanel implements ListCellRenderer {
      private JLabel nickLabel = new JLabel();
      private JLabel typeLabel = new JLabel();

      public AccountListCellRenderer() {
         this.setLayout(new BorderLayout(5, 5));
         this.add(this.nickLabel, "West");
         this.add(this.typeLabel, "East");
      }

      public Component getListCellRendererComponent(JList list, AccountEntry value, int index, boolean isSelected, boolean cellHasFocus) {
         this.nickLabel.setText(value.nick);
         this.typeLabel.setText(value.type);
         if (isSelected) {
            this.setBackground(list.getSelectionBackground());
            this.nickLabel.setForeground(list.getSelectionForeground());
            this.typeLabel.setForeground(list.getSelectionForeground());
         } else {
            this.setBackground(list.getBackground());
            this.nickLabel.setForeground(list.getForeground());
            this.typeLabel.setForeground(Color.GRAY);
         }

         return this;
      }
   }
}
