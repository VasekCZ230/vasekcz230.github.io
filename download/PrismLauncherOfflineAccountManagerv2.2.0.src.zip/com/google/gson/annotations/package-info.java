@CheckReturnValue
package com.google.gson.annotations;

import com.google.errorprone.annotations.CheckReturnValue;
