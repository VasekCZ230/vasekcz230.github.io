@CheckReturnValue
package com.google.gson.internal;

import com.google.errorprone.annotations.CheckReturnValue;
