package com.google.gson.internal;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Properties;

public final class GsonTypes {
   static final Type[] EMPTY_TYPE_ARRAY = new Type[0];

   private GsonTypes() {
      throw new UnsupportedOperationException();
   }

   public static ParameterizedType newParameterizedTypeWithOwner(Type ownerType, Class rawType, Type... typeArguments) {
      return new ParameterizedTypeImpl(ownerType, rawType, typeArguments);
   }

   public static GenericArrayType arrayOf(Type componentType) {
      return new GenericArrayTypeImpl(componentType);
   }

   public static WildcardType subtypeOf(Type bound) {
      Type[] upperBounds;
      if (bound instanceof WildcardType) {
         upperBounds = ((WildcardType)bound).getUpperBounds();
      } else {
         upperBounds = new Type[]{bound};
      }

      return new WildcardTypeImpl(upperBounds, EMPTY_TYPE_ARRAY);
   }

   public static WildcardType supertypeOf(Type bound) {
      Type[] lowerBounds;
      if (bound instanceof WildcardType) {
         lowerBounds = ((WildcardType)bound).getLowerBounds();
      } else {
         lowerBounds = new Type[]{bound};
      }

      return new WildcardTypeImpl(new Type[]{Object.class}, lowerBounds);
   }

   public static Type canonicalize(Type type) {
      if (type instanceof Class) {
         Class c = (Class)type;
         return (Type)(c.isArray() ? new GenericArrayTypeImpl(canonicalize(c.getComponentType())) : c);
      } else if (type instanceof ParameterizedType) {
         ParameterizedType p = (ParameterizedType)type;
         return new ParameterizedTypeImpl(p.getOwnerType(), (Class)p.getRawType(), p.getActualTypeArguments());
      } else if (type instanceof GenericArrayType) {
         GenericArrayType g = (GenericArrayType)type;
         return new GenericArrayTypeImpl(g.getGenericComponentType());
      } else if (type instanceof WildcardType) {
         WildcardType w = (WildcardType)type;
         return new WildcardTypeImpl(w.getUpperBounds(), w.getLowerBounds());
      } else {
         return type;
      }
   }

   public static Class getRawType(Type type) {
      if (type instanceof Class) {
         return (Class)type;
      } else if (type instanceof ParameterizedType) {
         ParameterizedType parameterizedType = (ParameterizedType)type;
         Type rawType = parameterizedType.getRawType();
         GsonPreconditions.checkArgument(rawType instanceof Class);
         return (Class)rawType;
      } else if (type instanceof GenericArrayType) {
         Type componentType = ((GenericArrayType)type).getGenericComponentType();
         return Array.newInstance(getRawType(componentType), 0).getClass();
      } else if (type instanceof TypeVariable) {
         return Object.class;
      } else if (type instanceof WildcardType) {
         Type[] bounds = ((WildcardType)type).getUpperBounds();

         assert bounds.length == 1;

         return getRawType(bounds[0]);
      } else {
         String className = type == null ? "null" : type.getClass().getName();
         throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type + "> is of type " + className);
      }
   }

   private static boolean equal(Object a, Object b) {
      return Objects.equals(a, b);
   }

   public static boolean equals(Type a, Type b) {
      if (a == b) {
         return true;
      } else if (a instanceof Class) {
         return a.equals(b);
      } else if (a instanceof ParameterizedType) {
         if (!(b instanceof ParameterizedType)) {
            return false;
         } else {
            ParameterizedType pa = (ParameterizedType)a;
            ParameterizedType pb = (ParameterizedType)b;
            return equal(pa.getOwnerType(), pb.getOwnerType()) && pa.getRawType().equals(pb.getRawType()) && Arrays.equals(pa.getActualTypeArguments(), pb.getActualTypeArguments());
         }
      } else if (a instanceof GenericArrayType) {
         if (!(b instanceof GenericArrayType)) {
            return false;
         } else {
            GenericArrayType ga = (GenericArrayType)a;
            GenericArrayType gb = (GenericArrayType)b;
            return equals(ga.getGenericComponentType(), gb.getGenericComponentType());
         }
      } else if (a instanceof WildcardType) {
         if (!(b instanceof WildcardType)) {
            return false;
         } else {
            WildcardType wa = (WildcardType)a;
            WildcardType wb = (WildcardType)b;
            return Arrays.equals(wa.getUpperBounds(), wb.getUpperBounds()) && Arrays.equals(wa.getLowerBounds(), wb.getLowerBounds());
         }
      } else if (a instanceof TypeVariable) {
         if (!(b instanceof TypeVariable)) {
            return false;
         } else {
            TypeVariable va = (TypeVariable)a;
            TypeVariable vb = (TypeVariable)b;
            return Objects.equals(va.getGenericDeclaration(), vb.getGenericDeclaration()) && va.getName().equals(vb.getName());
         }
      } else {
         return false;
      }
   }

   public static String typeToString(Type type) {
      return type instanceof Class ? ((Class)type).getName() : type.toString();
   }

   private static Type getGenericSupertype(Type context, Class rawType, Class supertype) {
      if (supertype == rawType) {
         return context;
      } else {
         if (supertype.isInterface()) {
            Class[] interfaces = rawType.getInterfaces();
            int i = 0;

            for(int length = interfaces.length; i < length; ++i) {
               if (interfaces[i] == supertype) {
                  return rawType.getGenericInterfaces()[i];
               }

               if (supertype.isAssignableFrom(interfaces[i])) {
                  return getGenericSupertype(rawType.getGenericInterfaces()[i], interfaces[i], supertype);
               }
            }
         }

         if (!rawType.isInterface()) {
            while(rawType != Object.class) {
               Class rawSupertype = rawType.getSuperclass();
               if (rawSupertype == supertype) {
                  return rawType.getGenericSuperclass();
               }

               if (supertype.isAssignableFrom(rawSupertype)) {
                  return getGenericSupertype(rawType.getGenericSuperclass(), rawSupertype, supertype);
               }

               rawType = rawSupertype;
            }
         }

         return supertype;
      }
   }

   private static Type getSupertype(Type context, Class contextRawType, Class supertype) {
      if (context instanceof WildcardType) {
         Type[] bounds = ((WildcardType)context).getUpperBounds();

         assert bounds.length == 1;

         context = bounds[0];
      }

      GsonPreconditions.checkArgument(supertype.isAssignableFrom(contextRawType));
      return resolve(context, contextRawType, getGenericSupertype(context, contextRawType, supertype));
   }

   public static Type getArrayComponentType(Type array) {
      return (Type)(array instanceof GenericArrayType ? ((GenericArrayType)array).getGenericComponentType() : ((Class)array).getComponentType());
   }

   public static Type getCollectionElementType(Type context, Class contextRawType) {
      Type collectionType = getSupertype(context, contextRawType, Collection.class);
      return (Type)(collectionType instanceof ParameterizedType ? ((ParameterizedType)collectionType).getActualTypeArguments()[0] : Object.class);
   }

   public static Type[] getMapKeyAndValueTypes(Type context, Class contextRawType) {
      if (Properties.class.isAssignableFrom(contextRawType)) {
         return new Type[]{String.class, String.class};
      } else {
         Type mapType = getSupertype(context, contextRawType, Map.class);
         if (mapType instanceof ParameterizedType) {
            ParameterizedType mapParameterizedType = (ParameterizedType)mapType;
            return mapParameterizedType.getActualTypeArguments();
         } else {
            return new Type[]{Object.class, Object.class};
         }
      }
   }

   public static Type resolve(Type context, Class contextRawType, Type toResolve) {
      return resolve(context, contextRawType, toResolve, new HashMap());
   }

   private static Type resolve(Type context, Class contextRawType, Type toResolve, Map visitedTypeVariables) {
      TypeVariable resolving = null;

      while(true) {
         Type ownerType;
         if (toResolve instanceof TypeVariable) {
            TypeVariable typeVariable = (TypeVariable)toResolve;
            ownerType = (Type)visitedTypeVariables.get(typeVariable);
            if (ownerType != null) {
               return (Type)(ownerType == Void.TYPE ? toResolve : ownerType);
            }

            visitedTypeVariables.put(typeVariable, Void.TYPE);
            if (resolving == null) {
               resolving = typeVariable;
            }

            toResolve = resolveTypeVariable(context, contextRawType, typeVariable);
            if (toResolve != typeVariable) {
               continue;
            }
         } else {
            Type newOwnerType;
            if (toResolve instanceof Class && ((Class)toResolve).isArray()) {
               Class original = (Class)toResolve;
               Type componentType = original.getComponentType();
               newOwnerType = resolve(context, contextRawType, componentType, visitedTypeVariables);
               toResolve = equal(componentType, newOwnerType) ? original : arrayOf(newOwnerType);
            } else if (toResolve instanceof GenericArrayType) {
               GenericArrayType original = (GenericArrayType)toResolve;
               ownerType = original.getGenericComponentType();
               newOwnerType = resolve(context, contextRawType, ownerType, visitedTypeVariables);
               toResolve = equal(ownerType, newOwnerType) ? original : arrayOf(newOwnerType);
            } else if (toResolve instanceof ParameterizedType) {
               ParameterizedType original = (ParameterizedType)toResolve;
               ownerType = original.getOwnerType();
               newOwnerType = resolve(context, contextRawType, ownerType, visitedTypeVariables);
               boolean ownerChanged = !equal(newOwnerType, ownerType);
               Type[] args = original.getActualTypeArguments();
               boolean argsChanged = false;
               int t = 0;

               for(int length = args.length; t < length; ++t) {
                  Type resolvedTypeArgument = resolve(context, contextRawType, args[t], visitedTypeVariables);
                  if (!equal(resolvedTypeArgument, args[t])) {
                     if (!argsChanged) {
                        args = (Type[])args.clone();
                        argsChanged = true;
                     }

                     args[t] = resolvedTypeArgument;
                  }
               }

               toResolve = !ownerChanged && !argsChanged ? original : newParameterizedTypeWithOwner(newOwnerType, (Class)original.getRawType(), args);
            } else if (toResolve instanceof WildcardType) {
               label75: {
                  WildcardType original = (WildcardType)toResolve;
                  Type[] originalLowerBound = original.getLowerBounds();
                  Type[] originalUpperBound = original.getUpperBounds();
                  Type upperBound;
                  if (originalLowerBound.length == 1) {
                     upperBound = resolve(context, contextRawType, originalLowerBound[0], visitedTypeVariables);
                     if (upperBound != originalLowerBound[0]) {
                        toResolve = supertypeOf(upperBound);
                        break label75;
                     }
                  } else if (originalUpperBound.length == 1) {
                     upperBound = resolve(context, contextRawType, originalUpperBound[0], visitedTypeVariables);
                     if (upperBound != originalUpperBound[0]) {
                        toResolve = subtypeOf(upperBound);
                        break label75;
                     }
                  }

                  toResolve = original;
               }
            }
         }

         if (resolving != null) {
            visitedTypeVariables.put(resolving, toResolve);
         }

         return (Type)toResolve;
      }
   }

   private static Type resolveTypeVariable(Type context, Class contextRawType, TypeVariable unknown) {
      Class declaredByRaw = declaringClassOf(unknown);
      if (declaredByRaw == null) {
         return unknown;
      } else {
         Type declaredBy = getGenericSupertype(context, contextRawType, declaredByRaw);
         if (declaredBy instanceof ParameterizedType) {
            int index = indexOf(declaredByRaw.getTypeParameters(), unknown);
            return ((ParameterizedType)declaredBy).getActualTypeArguments()[index];
         } else {
            return unknown;
         }
      }
   }

   private static int indexOf(Object[] array, Object toFind) {
      int i = 0;

      for(int length = array.length; i < length; ++i) {
         if (toFind.equals(array[i])) {
            return i;
         }
      }

      throw new NoSuchElementException();
   }

   private static Class declaringClassOf(TypeVariable typeVariable) {
      GenericDeclaration genericDeclaration = typeVariable.getGenericDeclaration();
      return genericDeclaration instanceof Class ? (Class)genericDeclaration : null;
   }

   static void checkNotPrimitive(Type type) {
      GsonPreconditions.checkArgument(!(type instanceof Class) || !((Class)type).isPrimitive());
   }

   public static boolean requiresOwnerType(Type rawType) {
      if (!(rawType instanceof Class)) {
         return false;
      } else {
         Class rawTypeAsClass = (Class)rawType;
         return !Modifier.isStatic(rawTypeAsClass.getModifiers()) && rawTypeAsClass.getDeclaringClass() != null;
      }
   }

   private static final class WildcardTypeImpl implements WildcardType, Serializable {
      private final Type upperBound;
      private final Type lowerBound;
      private static final long serialVersionUID = 0L;

      public WildcardTypeImpl(Type[] upperBounds, Type[] lowerBounds) {
         GsonPreconditions.checkArgument(lowerBounds.length <= 1);
         GsonPreconditions.checkArgument(upperBounds.length == 1);
         if (lowerBounds.length == 1) {
            Objects.requireNonNull(lowerBounds[0]);
            GsonTypes.checkNotPrimitive(lowerBounds[0]);
            GsonPreconditions.checkArgument(upperBounds[0] == Object.class);
            this.lowerBound = GsonTypes.canonicalize(lowerBounds[0]);
            this.upperBound = Object.class;
         } else {
            Objects.requireNonNull(upperBounds[0]);
            GsonTypes.checkNotPrimitive(upperBounds[0]);
            this.lowerBound = null;
            this.upperBound = GsonTypes.canonicalize(upperBounds[0]);
         }

      }

      public Type[] getUpperBounds() {
         return new Type[]{this.upperBound};
      }

      public Type[] getLowerBounds() {
         return this.lowerBound != null ? new Type[]{this.lowerBound} : GsonTypes.EMPTY_TYPE_ARRAY;
      }

      public boolean equals(Object other) {
         return other instanceof WildcardType && GsonTypes.equals(this, (WildcardType)other);
      }

      public int hashCode() {
         return (this.lowerBound != null ? 31 + this.lowerBound.hashCode() : 1) ^ 31 + this.upperBound.hashCode();
      }

      public String toString() {
         if (this.lowerBound != null) {
            return "? super " + GsonTypes.typeToString(this.lowerBound);
         } else {
            return this.upperBound == Object.class ? "?" : "? extends " + GsonTypes.typeToString(this.upperBound);
         }
      }
   }

   private static final class GenericArrayTypeImpl implements GenericArrayType, Serializable {
      private final Type componentType;
      private static final long serialVersionUID = 0L;

      public GenericArrayTypeImpl(Type componentType) {
         Objects.requireNonNull(componentType);
         this.componentType = GsonTypes.canonicalize(componentType);
      }

      public Type getGenericComponentType() {
         return this.componentType;
      }

      public boolean equals(Object o) {
         return o instanceof GenericArrayType && GsonTypes.equals(this, (GenericArrayType)o);
      }

      public int hashCode() {
         return this.componentType.hashCode();
      }

      public String toString() {
         return GsonTypes.typeToString(this.componentType) + "[]";
      }
   }

   private static final class ParameterizedTypeImpl implements ParameterizedType, Serializable {
      private final Type ownerType;
      private final Type rawType;
      private final Type[] typeArguments;
      private static final long serialVersionUID = 0L;

      public ParameterizedTypeImpl(Type ownerType, Class rawType, Type... typeArguments) {
         Objects.requireNonNull(rawType);
         if (ownerType == null && GsonTypes.requiresOwnerType(rawType)) {
            throw new IllegalArgumentException("Must specify owner type for " + rawType);
         } else {
            this.ownerType = ownerType == null ? null : GsonTypes.canonicalize(ownerType);
            this.rawType = GsonTypes.canonicalize(rawType);
            this.typeArguments = (Type[])typeArguments.clone();
            int t = 0;

            for(int length = this.typeArguments.length; t < length; ++t) {
               Objects.requireNonNull(this.typeArguments[t]);
               GsonTypes.checkNotPrimitive(this.typeArguments[t]);
               this.typeArguments[t] = GsonTypes.canonicalize(this.typeArguments[t]);
            }

         }
      }

      public Type[] getActualTypeArguments() {
         return (Type[])this.typeArguments.clone();
      }

      public Type getRawType() {
         return this.rawType;
      }

      public Type getOwnerType() {
         return this.ownerType;
      }

      public boolean equals(Object other) {
         return other instanceof ParameterizedType && GsonTypes.equals(this, (ParameterizedType)other);
      }

      private static int hashCodeOrZero(Object o) {
         return o != null ? o.hashCode() : 0;
      }

      public int hashCode() {
         return Arrays.hashCode(this.typeArguments) ^ this.rawType.hashCode() ^ hashCodeOrZero(this.ownerType);
      }

      public String toString() {
         int length = this.typeArguments.length;
         if (length == 0) {
            return GsonTypes.typeToString(this.rawType);
         } else {
            StringBuilder stringBuilder = new StringBuilder(30 * (length + 1));
            stringBuilder.append(GsonTypes.typeToString(this.rawType)).append("<").append(GsonTypes.typeToString(this.typeArguments[0]));

            for(int i = 1; i < length; ++i) {
               stringBuilder.append(", ").append(GsonTypes.typeToString(this.typeArguments[i]));
            }

            return stringBuilder.append(">").toString();
         }
      }
   }
}
