package com.google.gson.internal;

public interface ObjectConstructor {
   Object construct();
}
