package com.google.gson.internal;

import com.google.gson.InstanceCreator;
import com.google.gson.JsonIOException;
import com.google.gson.ReflectionAccessFilter;
import com.google.gson.internal.reflect.ReflectionHelper;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;

public final class ConstructorConstructor {
   private final Map instanceCreators;
   private final boolean useJdkUnsafe;
   private final List reflectionFilters;

   public ConstructorConstructor(Map instanceCreators, boolean useJdkUnsafe, List reflectionFilters) {
      this.instanceCreators = instanceCreators;
      this.useJdkUnsafe = useJdkUnsafe;
      this.reflectionFilters = reflectionFilters;
   }

   static String checkInstantiable(Class c) {
      int modifiers = c.getModifiers();
      if (Modifier.isInterface(modifiers)) {
         return "Interfaces can't be instantiated! Register an InstanceCreator or a TypeAdapter for this type. Interface name: " + c.getName();
      } else {
         return Modifier.isAbstract(modifiers) ? "Abstract classes can't be instantiated! Adjust the R8 configuration or register an InstanceCreator or a TypeAdapter for this type. Class name: " + c.getName() + "\nSee " + TroubleshootingGuide.createUrl("r8-abstract-class") : null;
      }
   }

   public ObjectConstructor get(TypeToken typeToken) {
      return this.get(typeToken, true);
   }

   public ObjectConstructor get(TypeToken typeToken, boolean allowUnsafe) {
      Type type = typeToken.getType();
      Class rawType = typeToken.getRawType();
      InstanceCreator typeCreator = (InstanceCreator)this.instanceCreators.get(type);
      if (typeCreator != null) {
         return () -> {
            return typeCreator.createInstance(type);
         };
      } else {
         InstanceCreator rawTypeCreator = (InstanceCreator)this.instanceCreators.get(rawType);
         if (rawTypeCreator != null) {
            return () -> {
               return rawTypeCreator.createInstance(type);
            };
         } else {
            ObjectConstructor specialConstructor = newSpecialCollectionConstructor(type, rawType);
            if (specialConstructor != null) {
               return specialConstructor;
            } else {
               ReflectionAccessFilter.FilterResult filterResult = ReflectionAccessFilterHelper.getFilterResult(this.reflectionFilters, rawType);
               ObjectConstructor defaultConstructor = newDefaultConstructor(rawType, filterResult);
               if (defaultConstructor != null) {
                  return defaultConstructor;
               } else {
                  ObjectConstructor defaultImplementation = newDefaultImplementationConstructor(type, rawType);
                  if (defaultImplementation != null) {
                     return defaultImplementation;
                  } else {
                     String exceptionMessage = checkInstantiable(rawType);
                     if (exceptionMessage != null) {
                        return () -> {
                           throw new JsonIOException(exceptionMessage);
                        };
                     } else {
                        String message;
                        if (!allowUnsafe) {
                           message = "Unable to create instance of " + rawType + "; Register an InstanceCreator or a TypeAdapter for this type.";
                           return () -> {
                              throw new JsonIOException(message);
                           };
                        } else if (filterResult != ReflectionAccessFilter.FilterResult.ALLOW) {
                           message = "Unable to create instance of " + rawType + "; ReflectionAccessFilter does not permit using reflection or Unsafe. Register an InstanceCreator or a TypeAdapter for this type or adjust the access filter to allow using reflection.";
                           return () -> {
                              throw new JsonIOException(message);
                           };
                        } else {
                           return this.newUnsafeAllocator(rawType);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static ObjectConstructor newSpecialCollectionConstructor(Type type, Class rawType) {
      if (EnumSet.class.isAssignableFrom(rawType)) {
         return () -> {
            if (type instanceof ParameterizedType) {
               Type elementType = ((ParameterizedType)type).getActualTypeArguments()[0];
               if (elementType instanceof Class) {
                  Object set = EnumSet.noneOf((Class)elementType);
                  return set;
               } else {
                  throw new JsonIOException("Invalid EnumSet type: " + type.toString());
               }
            } else {
               throw new JsonIOException("Invalid EnumSet type: " + type.toString());
            }
         };
      } else {
         return rawType == EnumMap.class ? () -> {
            if (type instanceof ParameterizedType) {
               Type elementType = ((ParameterizedType)type).getActualTypeArguments()[0];
               if (elementType instanceof Class) {
                  Object map = new EnumMap((Class)elementType);
                  return map;
               } else {
                  throw new JsonIOException("Invalid EnumMap type: " + type.toString());
               }
            } else {
               throw new JsonIOException("Invalid EnumMap type: " + type.toString());
            }
         } : null;
      }
   }

   private static ObjectConstructor newDefaultConstructor(Class rawType, ReflectionAccessFilter.FilterResult filterResult) {
      if (Modifier.isAbstract(rawType.getModifiers())) {
         return null;
      } else {
         Constructor constructor;
         try {
            constructor = rawType.getDeclaredConstructor();
         } catch (NoSuchMethodException var5) {
            return null;
         }

         boolean canAccess = filterResult == ReflectionAccessFilter.FilterResult.ALLOW || ReflectionAccessFilterHelper.canAccess(constructor, (Object)null) && (filterResult != ReflectionAccessFilter.FilterResult.BLOCK_ALL || Modifier.isPublic(constructor.getModifiers()));
         String exceptionMessage;
         if (!canAccess) {
            exceptionMessage = "Unable to invoke no-args constructor of " + rawType + "; constructor is not accessible and ReflectionAccessFilter does not permit making it accessible. Register an InstanceCreator or a TypeAdapter for this type, change the visibility of the constructor or adjust the access filter.";
            return () -> {
               throw new JsonIOException(exceptionMessage);
            };
         } else {
            if (filterResult == ReflectionAccessFilter.FilterResult.ALLOW) {
               exceptionMessage = ReflectionHelper.tryMakeAccessible(constructor);
               if (exceptionMessage != null) {
                  return () -> {
                     throw new JsonIOException(exceptionMessage);
                  };
               }
            }

            return () -> {
               try {
                  Object newInstance = constructor.newInstance();
                  return newInstance;
               } catch (InstantiationException var2) {
                  throw new RuntimeException("Failed to invoke constructor '" + ReflectionHelper.constructorToString(constructor) + "' with no args", var2);
               } catch (InvocationTargetException var3) {
                  throw new RuntimeException("Failed to invoke constructor '" + ReflectionHelper.constructorToString(constructor) + "' with no args", var3.getCause());
               } catch (IllegalAccessException var4) {
                  throw ReflectionHelper.createExceptionForUnexpectedIllegalAccess(var4);
               }
            };
         }
      }
   }

   private static ObjectConstructor newDefaultImplementationConstructor(Type type, Class rawType) {
      ObjectConstructor constructor;
      if (Collection.class.isAssignableFrom(rawType)) {
         constructor = newCollectionConstructor(rawType);
         return constructor;
      } else if (Map.class.isAssignableFrom(rawType)) {
         constructor = newMapConstructor(type, rawType);
         return constructor;
      } else {
         return null;
      }
   }

   private static ObjectConstructor newCollectionConstructor(Class rawType) {
      if (rawType.isAssignableFrom(ArrayList.class)) {
         return () -> {
            return new ArrayList();
         };
      } else if (rawType.isAssignableFrom(LinkedHashSet.class)) {
         return () -> {
            return new LinkedHashSet();
         };
      } else if (rawType.isAssignableFrom(TreeSet.class)) {
         return () -> {
            return new TreeSet();
         };
      } else {
         return rawType.isAssignableFrom(ArrayDeque.class) ? () -> {
            return new ArrayDeque();
         } : null;
      }
   }

   private static boolean hasStringKeyType(Type mapType) {
      if (!(mapType instanceof ParameterizedType)) {
         return true;
      } else {
         Type[] typeArguments = ((ParameterizedType)mapType).getActualTypeArguments();
         if (typeArguments.length == 0) {
            return false;
         } else {
            return GsonTypes.getRawType(typeArguments[0]) == String.class;
         }
      }
   }

   private static ObjectConstructor newMapConstructor(Type type, Class rawType) {
      if (rawType.isAssignableFrom(LinkedTreeMap.class) && hasStringKeyType(type)) {
         return () -> {
            return new LinkedTreeMap();
         };
      } else if (rawType.isAssignableFrom(LinkedHashMap.class)) {
         return () -> {
            return new LinkedHashMap();
         };
      } else if (rawType.isAssignableFrom(TreeMap.class)) {
         return () -> {
            return new TreeMap();
         };
      } else if (rawType.isAssignableFrom(ConcurrentHashMap.class)) {
         return () -> {
            return new ConcurrentHashMap();
         };
      } else {
         return rawType.isAssignableFrom(ConcurrentSkipListMap.class) ? () -> {
            return new ConcurrentSkipListMap();
         } : null;
      }
   }

   private ObjectConstructor newUnsafeAllocator(Class rawType) {
      if (this.useJdkUnsafe) {
         return () -> {
            try {
               Object newInstance = UnsafeAllocator.INSTANCE.newInstance(rawType);
               return newInstance;
            } catch (Exception var2) {
               throw new RuntimeException("Unable to create instance of " + rawType + ". Registering an InstanceCreator or a TypeAdapter for this type, or adding a no-args constructor may fix this problem.", var2);
            }
         };
      } else {
         String exceptionMessage = "Unable to create instance of " + rawType + "; usage of JDK Unsafe is disabled. Registering an InstanceCreator or a TypeAdapter for this type, adding a no-args constructor, or enabling usage of JDK Unsafe may fix this problem.";
         if (rawType.getDeclaredConstructors().length == 0) {
            exceptionMessage = exceptionMessage + " Or adjust your R8 configuration to keep the no-args constructor of the class.";
         }

         return () -> {
            throw new JsonIOException(exceptionMessage);
         };
      }
   }

   public String toString() {
      return this.instanceCreators.toString();
   }
}
