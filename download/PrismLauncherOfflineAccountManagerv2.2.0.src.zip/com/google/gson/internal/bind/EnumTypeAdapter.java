package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.SerializedName;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

class EnumTypeAdapter extends TypeAdapter {
   static final TypeAdapterFactory FACTORY = new TypeAdapterFactory() {
      public TypeAdapter create(Gson gson, TypeToken typeToken) {
         Class rawType = typeToken.getRawType();
         if (Enum.class.isAssignableFrom(rawType) && rawType != Enum.class) {
            if (!rawType.isEnum()) {
               rawType = rawType.getSuperclass();
            }

            TypeAdapter adapter = new EnumTypeAdapter(rawType);
            return adapter;
         } else {
            return null;
         }
      }
   };
   private final Map nameToConstant;
   private final Map stringToConstant;
   private final Map constantToName;

   private EnumTypeAdapter(Class classOfT) {
      this.nameToConstant = new HashMap();
      this.stringToConstant = new HashMap();
      this.constantToName = new HashMap();

      try {
         Field[] fields = classOfT.getDeclaredFields();
         int constantCount = 0;
         Field[] var4 = fields;
         int var5 = fields.length;

         int var6;
         Field constantField;
         for(var6 = 0; var6 < var5; ++var6) {
            constantField = var4[var6];
            if (constantField.isEnumConstant()) {
               fields[constantCount++] = constantField;
            }
         }

         fields = (Field[])Arrays.copyOf(fields, constantCount);
         AccessibleObject.setAccessible(fields, true);
         var4 = fields;
         var5 = fields.length;

         for(var6 = 0; var6 < var5; ++var6) {
            constantField = var4[var6];
            Enum constant = (Enum)constantField.get((Object)null);
            String name = constant.name();
            String toStringVal = constant.toString();
            SerializedName annotation = (SerializedName)constantField.getAnnotation(SerializedName.class);
            if (annotation != null) {
               name = annotation.value();
               String[] var12 = annotation.alternate();
               int var13 = var12.length;

               for(int var14 = 0; var14 < var13; ++var14) {
                  String alternate = var12[var14];
                  this.nameToConstant.put(alternate, constant);
               }
            }

            this.nameToConstant.put(name, constant);
            this.stringToConstant.put(toStringVal, constant);
            this.constantToName.put(constant, name);
         }

      } catch (IllegalAccessException var16) {
         throw new AssertionError(var16);
      }
   }

   public Enum read(JsonReader in) throws IOException {
      if (in.peek() == JsonToken.NULL) {
         in.nextNull();
         return null;
      } else {
         String key = in.nextString();
         Enum constant = (Enum)this.nameToConstant.get(key);
         return constant == null ? (Enum)this.stringToConstant.get(key) : constant;
      }
   }

   public void write(JsonWriter out, Enum value) throws IOException {
      out.value(value == null ? null : (String)this.constantToName.get(value));
   }

   // $FF: synthetic method
   EnumTypeAdapter(Class x0, Object x1) {
      this(x0);
   }
}
