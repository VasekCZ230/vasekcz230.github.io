package com.google.gson;

public enum Strictness {
   LENIENT,
   LEGACY_STRICT,
   STRICT;
}
