@CheckReturnValue
package com.google.gson.reflect;

import com.google.errorprone.annotations.CheckReturnValue;
