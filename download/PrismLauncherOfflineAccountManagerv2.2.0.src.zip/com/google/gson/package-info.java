@CheckReturnValue
package com.google.gson;

import com.google.errorprone.annotations.CheckReturnValue;
