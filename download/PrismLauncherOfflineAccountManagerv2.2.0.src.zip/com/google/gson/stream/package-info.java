@CheckReturnValue
package com.google.gson.stream;

import com.google.errorprone.annotations.CheckReturnValue;
